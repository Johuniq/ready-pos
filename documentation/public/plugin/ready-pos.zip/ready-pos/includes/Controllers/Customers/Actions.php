<?php
/**
 * Customer-related POS actions.
 *
 * @package Readypos\Controllers\Customers
 * @since 1.0.0
 */

namespace Readypos\Controllers\Customers;

use Readypos\Models\POSCustomer;
use Readypos\Traits\Cacheable;

defined( 'ABSPATH' ) || exit;

/**
 * Class Actions
 *
 * Handles customer search, retrieval, creation, updating, listing, and deletion.
 *
 * @package Readypos\Controllers\Customers
 */
class Actions {

	use Cacheable;

	/**
	 * Paginated customer list for the back-office management page.
	 *
	 * Accepts:
	 *  - search (string)  Optional search keyword.
	 *  - page   (int)     Page number (default 1).
	 *  - limit  (int)     Per-page count (default 20, max 100).
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function list( \WP_REST_Request $request ) {
		$search = $request->get_param( 'search' ) ? sanitize_text_field( $request->get_param( 'search' ) ) : '';
		$page   = max( 1, intval( $request->get_param( 'page' ) ?: 1 ) );
		$limit  = intval( $request->get_param( 'limit' ) ?: 20 );
		$limit  = max( 1, min( 100, $limit ) );

		// Cache key includes all request parameters
		$cache_key = "customers_list_{$search}_{$page}_{$limit}";

		return $this->cache_response(
			$cache_key,
			function() use ( $search, $page, $limit ) {
				return $this->list_customers_internal( $search, $page, $limit );
			},
			'customers',
			0 // use Cache::CACHE_GROUPS['customers'] default (10s)
		);
	}

	/**
	 * Internal method to list customers (used for caching).
	 *
	 * @param string $search Search term.
	 * @param int    $page Page number.
	 * @param int    $limit Results per page.
	 * @return \WP_REST_Response
	 */
	private function list_customers_internal( $search, $page, $limit ) {		$args = array(
			'role__in' => array( 'customer', 'subscriber' ),
			'orderby'  => 'registered',
			'order'    => 'DESC',
			'number'   => $limit,
			'offset'   => ( $page - 1 ) * $limit,
			'count_total' => true,
		);

		if ( ! empty( $search ) ) {
			$is_phone_search = is_numeric( str_replace( array( '+', '-', ' ' ), '', $search ) );

			if ( $is_phone_search ) {
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Billing phone lookup is required for POS customer search.
				$args['meta_query'] = array(
					array(
						'key'     => 'billing_phone',
						'value'   => $search,
						'compare' => 'LIKE',
					),
				);
			} else {
				$args['search']         = '*' . $search . '*';
				$args['search_columns'] = array( 'user_login', 'user_nicename', 'user_email', 'display_name' );
			}
		}

		$query = new \WP_User_Query( $args );
		$users = $query->get_results();
		$total = (int) $query->get_total();

		// Pre-fetch POSCustomer records to avoid N+1 queries
		$user_ids = wp_list_pluck( $users, 'ID' );
		$pos_customers = array();
		if ( ! empty( $user_ids ) ) {
			$records = POSCustomer::whereIn( 'wc_customer_id', $user_ids )->get();
			foreach ( $records as $record ) {
				$pos_customers[ $record->wc_customer_id ] = $record;
			}
		}

		$customers = array();
		foreach ( $users as $user ) {
			$customers[] = $this->format_customer( $user, $pos_customers );
		}

		$total_pages = $limit > 0 ? (int) ceil( $total / $limit ) : 1;

		return new \WP_REST_Response(
			array(
				'customers'   => $customers,
				'total'       => $total,
				'page'        => $page,
				'total_pages' => max( 1, $total_pages ),
				'limit'       => $limit,
			),
			200
		);
	}

	/**
	 * Search WooCommerce/WordPress customers (typeahead for the POS terminal).
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function search( \WP_REST_Request $request ) {
		$search = $request->get_param( 'search' ) ? sanitize_text_field( $request->get_param( 'search' ) ) : '';

		if ( empty( $search ) ) {
			// Return recent customers
			$users = get_users(
				array(
					'role__in' => array( 'customer', 'subscriber' ),
					'number'   => 15,
					'orderby'  => 'registered',
					'order'    => 'DESC',
				)
			);
		} else {
			// Search customers by search keyword (email, name, username, billing phone)
			$user_query_args = array(
				'role__in'       => array( 'customer', 'subscriber' ),
				'search'         => '*' . $search . '*',
				'search_columns' => array( 'user_login', 'user_nicename', 'user_email', 'display_name' ),
				'number'         => 30,
			);

			// Check if search keyword is a phone number to search billing_phone meta
			if ( is_numeric( str_replace( array( '+', '-', ' ' ), '', $search ) ) ) {
				unset( $user_query_args['search'] );
				unset( $user_query_args['search_columns'] );
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Billing phone lookup is required for POS customer search.
				$user_query_args['meta_query'] = array(
					array(
						'key'     => 'billing_phone',
						'value'   => $search,
						'compare' => 'LIKE',
					),
				);
			}

			$users = get_users( $user_query_args );
		}

		// Pre-fetch POSCustomer records to avoid N+1 queries
		$user_ids = wp_list_pluck( $users, 'ID' );
		$pos_customers = array();
		if ( ! empty( $user_ids ) ) {
			$records = POSCustomer::whereIn( 'wc_customer_id', $user_ids )->get();
			foreach ( $records as $record ) {
				$pos_customers[ $record->wc_customer_id ] = $record;
			}
		}

		$customers = array();
		foreach ( $users as $user ) {
			$customers[] = $this->format_customer( $user, $pos_customers );
		}

		return new \WP_REST_Response( $customers, 200 );
	}

	/**
	 * Create a new customer in WooCommerce.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create( \WP_REST_Request $request ) {
		$first_name = sanitize_text_field( $request->get_param( 'firstName' ) );
		$last_name  = sanitize_text_field( $request->get_param( 'lastName' ) );
		$email      = sanitize_email( $request->get_param( 'email' ) );
		$phone      = sanitize_text_field( $request->get_param( 'phone' ) );
		$notes      = sanitize_textarea_field( (string) $request->get_param( 'notes' ) );

		if ( empty( $first_name ) ) {
			return new \WP_Error( 'missing_fields', __( 'First name is required.', 'ready-pos-for-woocommerce' ), array( 'status' => 400 ) );
		}

		// Generate unique username from name or email
		$username = ! empty( $email ) ? explode( '@', $email )[0] : strtolower( $first_name . '_' . wp_rand( 100, 999 ) );
		$username = sanitize_user( $username );

		if ( username_exists( $username ) ) {
			$username = $username . wp_rand( 10, 99 );
		}

		if ( ! empty( $email ) && email_exists( $email ) ) {
			return new \WP_Error( 'email_exists', __( 'Customer with this email already exists.', 'ready-pos-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$user_id = wp_create_user( $username, wp_generate_password(), $email ?: '' );

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		// Update user information
		wp_update_user(
			array(
				'ID'         => $user_id,
				'first_name' => $first_name,
				'last_name'  => $last_name,
				'role'       => 'customer',
			)
		);

		// Save WooCommerce billing details
		update_user_meta( $user_id, 'billing_first_name', $first_name );
		update_user_meta( $user_id, 'billing_last_name', $last_name );
		update_user_meta( $user_id, 'billing_phone', $phone );
		if ( ! empty( $email ) ) {
			update_user_meta( $user_id, 'billing_email', $email );
		}

		// Store POS-specific customer data
		POSCustomer::create(
			array(
				'wc_customer_id' => $user_id,
				'first_name'     => $first_name,
				'last_name'      => $last_name,
				'email'          => $email,
				'phone'          => $phone,
				'notes'          => $notes,
				'loyalty_points' => 0,
				'total_spent'    => 0,
				'visit_count'    => 0,
			)
		);

		$user = get_userdata( $user_id );

		// Invalidate customer caches
		$this->invalidate_cache( 'customer', $user_id );

		return new \WP_REST_Response( $this->format_customer( $user ), 200 );
	}

	/**
	 * Retrieve a single customer.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_detail( \WP_REST_Request $request ) {
		$user_id = intval( $request->get_param( 'id' ) );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return new \WP_Error( 'not_found', __( 'Customer not found.', 'ready-pos-for-woocommerce' ), array( 'status' => 404 ) );
		}

		return new \WP_REST_Response( $this->format_customer( $user ), 200 );
	}

	/**
	 * Update customer info.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update( \WP_REST_Request $request ) {
		$user_id    = intval( $request->get_param( 'id' ) );
		$first_name = sanitize_text_field( $request->get_param( 'firstName' ) );
		$last_name  = sanitize_text_field( $request->get_param( 'lastName' ) );
		$email      = sanitize_email( $request->get_param( 'email' ) );
		$phone      = sanitize_text_field( $request->get_param( 'phone' ) );
		$notes      = sanitize_textarea_field( (string) $request->get_param( 'notes' ) );

		if ( empty( $first_name ) ) {
			return new \WP_Error( 'missing_fields', __( 'First name is required.', 'ready-pos-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return new \WP_Error( 'not_found', __( 'Customer not found.', 'ready-pos-for-woocommerce' ), array( 'status' => 404 ) );
		}

		// Email check
		if ( ! empty( $email ) && $email !== $user->user_email && email_exists( $email ) ) {
			return new \WP_Error( 'email_exists', __( 'Customer with this email already exists.', 'ready-pos-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$update_args = array(
			'ID'         => $user_id,
			'first_name' => $first_name,
			'last_name'  => $last_name,
		);

		// Only update user_email when a non-empty email is supplied to avoid
		// wiping the existing email or triggering wp_update_user validation errors.
		if ( ! empty( $email ) ) {
			$update_args['user_email'] = $email;
		}

		wp_update_user( $update_args );

		update_user_meta( $user_id, 'billing_first_name', $first_name );
		update_user_meta( $user_id, 'billing_last_name', $last_name );
		update_user_meta( $user_id, 'billing_phone', $phone );
		if ( ! empty( $email ) ) {
			update_user_meta( $user_id, 'billing_email', $email );
		}

		// Update or create POS customer record
		$pos_customer = POSCustomer::where( 'wc_customer_id', $user_id )->first();
		if ( $pos_customer ) {
			$pos_customer->first_name = $first_name;
			$pos_customer->last_name  = $last_name;
			$pos_customer->email      = $email;
			$pos_customer->phone      = $phone;
			$pos_customer->notes      = $notes;
			$pos_customer->save();
		} else {
			POSCustomer::create(
				array(
					'wc_customer_id' => $user_id,
					'first_name'     => $first_name,
					'last_name'      => $last_name,
					'email'          => $email,
					'phone'          => $phone,
					'notes'          => $notes,
				)
			);
		}

		// Invalidate customer caches
		$this->invalidate_cache( 'customer', $user_id );

		return new \WP_REST_Response( $this->format_customer( get_userdata( $user_id ) ), 200 );
	}

	/**
	 * Delete a customer.
	 *
	 * Removes both the linked WordPress user account (reassigning their content
	 * to nothing) and the matching POS customer profile.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function delete( \WP_REST_Request $request ) {
		$user_id = intval( $request->get_param( 'id' ) );

		if ( ! $user_id ) {
			return new \WP_Error( 'invalid_id', __( 'A valid customer id is required.', 'ready-pos-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return new \WP_Error( 'not_found', __( 'Customer not found.', 'ready-pos-for-woocommerce' ), array( 'status' => 404 ) );
		}

		// Refuse to delete a user that holds privileged roles (admins, shop managers).
		$privileged_roles = array( 'administrator', 'shop_manager' );
		if ( array_intersect( $privileged_roles, (array) $user->roles ) ) {
			return new \WP_Error(
				'cannot_delete_staff',
				__( 'Privileged users cannot be deleted from the customer manager.', 'ready-pos-for-woocommerce' ),
				array( 'status' => 403 )
			);
		}

		// Load user.php file if wp_delete_user function is not available.
		if ( ! function_exists( 'wp_delete_user' ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		$deleted = wp_delete_user( $user_id );

		if ( ! $deleted ) {
			return new \WP_Error( 'delete_failed', __( 'Failed to delete customer.', 'ready-pos-for-woocommerce' ), array( 'status' => 500 ) );
		}

		// Remove linked POS customer record(s).
		POSCustomer::where( 'wc_customer_id', $user_id )->delete();

		// Invalidate customer caches
		$this->invalidate_cache( 'customer', $user_id );

		return new \WP_REST_Response(
			array(
				'success' => true,
				'id'      => $user_id,
			),
			200
		);
	}

	/**
	 * Get purchase history for a customer.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function purchase_history( \WP_REST_Request $request ) {
		$user_id = intval( $request->get_param( 'id' ) );
		$page    = max( 1, intval( $request->get_param( 'page' ) ?: 1 ) );
		$limit   = max( 1, min( 50, intval( $request->get_param( 'limit' ) ?: 10 ) ) );

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return new \WP_Error( 'not_found', __( 'Customer not found.', 'ready-pos-for-woocommerce' ), array( 'status' => 404 ) );
		}

		// Get all order IDs for this customer to count total
		$all_orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'limit'       => -1,
				'return'      => 'objects',
			)
		);

		$total = is_array( $all_orders ) ? count( $all_orders ) : 0;

		// Get paginated orders
		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'limit'       => $limit,
				'offset'      => ( $page - 1 ) * $limit,
				'orderby'     => 'date',
				'order'       => 'DESC',
				'return'      => 'objects',
			)
		);

		$history = array();
		foreach ( $orders as $order ) {
			$history[] = array(
				'id'             => $order->get_id(),
				'order_number'   => $order->get_order_number(),
				'total'          => floatval( $order->get_total() ),
				'status'         => $order->get_status(),
				'payment_method' => $order->get_payment_method_title(),
				'items_count'    => $order->get_item_count(),
				'date'           => $order->get_date_created() ? $order->get_date_created()->date( 'Y-m-d H:i:s' ) : '',
			);
		}

		return new \WP_REST_Response(
			array(
				'orders'      => $history,
				'total'       => $total,
				'page'        => $page,
				'total_pages' => max( 1, (int) ceil( $total / $limit ) ),
			),
			200
		);
	}

	/**
	 * Redeem loyalty points as a cart discount.
	 *
	 * Accepts:
	 *  - id     (int)  Customer WP user ID.
	 *  - points (int)  Number of points to redeem.
	 *
	 * Conversion: 100 points = $1 discount.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function redeem_points( \WP_REST_Request $request ) {
		$user_id = intval( $request->get_param( 'id' ) );
		$points  = intval( $request->get_param( 'points' ) );

		if ( $points <= 0 ) {
			return new \WP_Error( 'invalid_points', __( 'Points must be greater than zero.', 'ready-pos-for-woocommerce' ), array( 'status' => 400 ) );
		}

		$pos_customer = POSCustomer::where( 'wc_customer_id', $user_id )->first();

		// If no POS loyalty row exists yet, lazy-create one seeded from the
		// same live WooCommerce order stats the customer list uses. This
		// keeps the redeem endpoint consistent with what the operator sees
		// in the terminal (live points for users without a record).
		if ( ! $pos_customer ) {
			$user = get_userdata( $user_id );
			if ( ! $user ) {
				return new \WP_Error( 'not_found', __( 'Customer loyalty record not found.', 'ready-pos-for-woocommerce' ), array( 'status' => 404 ) );
			}

			$stats = $this->compute_live_stats( $user_id );

			$pos_customer = POSCustomer::create(
				array(
					'wc_customer_id' => $user_id,
					'first_name'     => $user->first_name ?: $user->display_name,
					'last_name'      => $user->last_name,
					'email'          => $user->user_email,
					'phone'          => get_user_meta( $user_id, 'billing_phone', true ),
					'loyalty_points' => $stats['loyalty_points'],
					'total_spent'    => $stats['total_spent'],
					'visit_count'    => $stats['visit_count'],
				)
			);
		}

		if ( $pos_customer->loyalty_points < $points ) {
			return new \WP_Error(
				'insufficient_points',
				__( 'Customer does not have enough loyalty points.', 'ready-pos-for-woocommerce' ),
				array( 'status' => 400 )
			);
		}

		// Deduct points.
		$pos_customer->loyalty_points -= $points;
		$pos_customer->save();

		// Conversion: 100 points = $1.
		$discount_amount = round( $points / 100, 2 );

		// Bust customer caches so list/detail views reflect the new balance.
		$this->invalidate_cache( 'customer', $user_id );

		return new \WP_REST_Response(
			array(
				'success'          => true,
				'points_redeemed'  => $points,
				'discount_amount'  => $discount_amount,
				'remaining_points' => intval( $pos_customer->loyalty_points ),
			),
			200
		);
	}

	/**
	 * Helper function to format customer data.
	 *
	 * @param \WP_User $user WordPress User object.
	 * @param array    $pos_customers Pre-loaded POS customer records.
	 * @return array
	 */
	private function format_customer( $user, $pos_customers = array() ) {
		$pos_customer = null;
		if ( isset( $pos_customers[ $user->ID ] ) ) {
			$pos_customer = $pos_customers[ $user->ID ];
		} else if ( empty( $pos_customers ) ) {
			$pos_customer = POSCustomer::where( 'wc_customer_id', $user->ID )->first();
		}

		// If a POS customer record exists, trust its cached counters.
		// Otherwise compute live stats from real WooCommerce orders so the
		// customers page and detail modal show accurate numbers for users
		// that have no readypos_customers row yet.
		if ( $pos_customer ) {
			$loyalty_points = intval( $pos_customer->loyalty_points );
			$visit_count    = intval( $pos_customer->visit_count );
			$total_spent    = floatval( $pos_customer->total_spent );
		} else {
			$stats                  = $this->compute_live_stats( $user->ID );
			$loyalty_points         = $stats['loyalty_points'];
			$visit_count            = $stats['visit_count'];
			$total_spent            = $stats['total_spent'];
		}

		return array(
			'id'             => $user->ID,
			'username'       => $user->user_login,
			'first_name'     => $user->first_name ?: $user->display_name,
			'last_name'      => $user->last_name,
			'email'          => $user->user_email,
			'phone'          => get_user_meta( $user->ID, 'billing_phone', true ) ?: ( $pos_customer ? $pos_customer->phone : '' ),
			'notes'          => $pos_customer ? (string) $pos_customer->notes : '',
			'loyalty_points' => $loyalty_points,
			'visit_count'    => $visit_count,
			'total_spent'    => $total_spent,
			'registered_at'  => $user->user_registered,
		);
	}

	/**
	 * Compute customer stats directly from WooCommerce orders.
	 *
	 * Used as a fallback when the customer has no readypos_customers record,
	 * so the customers list and detail modal still surface real activity.
	 *
	 * @param int $user_id WordPress user ID.
	 * @return array{visit_count:int,total_spent:float,loyalty_points:int}
	 */
	private function compute_live_stats( $user_id ) {
		$user_id = intval( $user_id );
		if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
			return array(
				'visit_count'    => 0,
				'total_spent'    => 0.0,
				'loyalty_points' => 0,
			);
		}

		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				// Refunded orders are excluded so the totals reflect money
				// the customer has actually spent (matching the POS loyalty
				// reward logic of 1 point per $1).
				'status'      => array( 'completed', 'processing' ),
				'limit'       => -1,
				'return'      => 'objects',
			)
		);

		if ( empty( $orders ) ) {
			return array(
				'visit_count'    => 0,
				'total_spent'    => 0.0,
				'loyalty_points' => 0,
			);
		}

		$total_spent = 0.0;
		foreach ( $orders as $order ) {
			$total_spent += floatval( $order->get_total() );
		}

		return array(
			'visit_count'    => count( $orders ),
			'total_spent'    => $total_spent,
			// 1 loyalty point per $1 spent (matches checkout loyalty rule).
			'loyalty_points' => (int) floor( $total_spent ),
		);
	}
}
