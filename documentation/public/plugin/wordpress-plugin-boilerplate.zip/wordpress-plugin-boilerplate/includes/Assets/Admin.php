<?php
/**
 * Admin Assets Enqueue.
 *
 * @package Readypos\Assets
 * @since 1.0.0
 */

declare(strict_types=1);

namespace Readypos\Assets;

use Readypos\Traits\Base;
use Readypos\Libs\Assets;

/**
 * Class Admin
 *
 * Handles enqueuing React assets for the admin pages.
 *
 * @package Readypos\Assets
 */
class Admin {

	use Base;

	/**
	 * Script handle.
	 */
	const HANDLE = 'ready-pos-admin';

	/**
	 * Localized JS global object name.
	 */
	const OBJ_NAME = 'readyPosAdmin';

	/**
	 * Dev entry script.
	 */
	const DEV_SCRIPT = 'src/admin/main.jsx';

	/**
	 * Allowed screens for script enqueue.
	 *
	 * @var array
	 */
	private $allowed_screens = array(
		'toplevel_page_ready-pos',
	);

	/**
	 * Bootstrap assets actions.
	 *
	 * @return void
	 */
	public function bootstrap() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_script' ) );
	}

	/**
	 * Enqueue assets.
	 *
	 * @param string $screen Current admin screen ID.
	 * @return void
	 */
	public function enqueue_script( $screen ) {
		if ( in_array( $screen, $this->allowed_screens, true ) ) {
			Assets\enqueue_asset(
				READYPOS_DIR . '/assets/admin/dist',
				self::DEV_SCRIPT,
				$this->get_config()
			);
			wp_localize_script( self::HANDLE, self::OBJ_NAME, $this->get_data() );

			// PWA: inject manifest link and service worker registration.
			add_action(
				'admin_head',
				function () {
					$manifest_url = plugins_url( 'assets/manifest.json', READYPOS_PLUGIN_FILE );
					echo '<link rel="manifest" href="' . esc_url( $manifest_url ) . '">' . "\n";
					echo '<meta name="theme-color" content="#2563eb">' . "\n";
				}
			);

			add_action(
				'admin_footer',
				function () {
					$sw_url = plugins_url( 'src/admin/sw.js', READYPOS_PLUGIN_FILE );
					?>
					<script>
					if ('serviceWorker' in navigator) {
						window.addEventListener('load', function() {
							navigator.serviceWorker.register('<?php echo esc_url( $sw_url ); ?>', { scope: '/wp-admin/' })
								.then(function(reg) { console.log('[ReadyPOS] SW registered:', reg.scope); })
								.catch(function(err) { console.warn('[ReadyPOS] SW registration failed:', err); });
						});
					}
					</script>
					<?php
				}
			);
		}
	}

	/**
	 * Asset config.
	 *
	 * @return array
	 */
	public function get_config() {
		return array(
			'dependencies' => array( 'react', 'react-dom' ),
			'handle'       => self::HANDLE,
			'in-footer'    => true,
		);
	}

	/**
	 * Data passed to React application.
	 *
	 * @return array
	 */
	public function get_data() {
		return array(
			'isAdmin'             => is_admin(),
			'apiUrl'              => rest_url( READYPOS_ROUTE_PREFIX ),
			'restNonce'           => wp_create_nonce( 'wp_rest' ),
			'userInfo'            => $this->get_user_data(),
			'currency'            => $this->get_currency_data(),
			'onboardingComplete'  => get_option( 'readypos_onboarding_complete', 'no' ) === 'yes',
		);
	}

	/**
	 * Get current user data.
	 *
	 * @return array
	 */
	private function get_user_data() {
		$username   = '';
		$avatar_url = '';
		$roles      = array();

		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$username     = $current_user->display_name;
			$avatar_url   = get_avatar_url( $current_user->ID );
			$roles        = (array) $current_user->roles;
		}

		return array(
			'username' => $username,
			'avatar'   => $avatar_url,
			'roles'    => $roles,
		);
	}

	/**
	 * Retrieve WooCommerce currency settings.
	 *
	 * @return array
	 */
	private function get_currency_data() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array(
				'symbol'    => '$',
				'code'      => 'USD',
				'position'  => 'left',
				'decimals'  => 2,
				'thousand'  => ',',
				'decimal'   => '.',
			);
		}

		return array(
			'symbol'    => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
			'code'      => get_woocommerce_currency(),
			'position'  => get_option( 'woocommerce_currency_pos', 'left' ),
			'decimals'  => wc_get_price_decimals(),
			'thousand'  => html_entity_decode( wc_get_price_thousand_separator(), ENT_QUOTES, 'UTF-8' ),
			'decimal'   => html_entity_decode( wc_get_price_decimal_separator(), ENT_QUOTES, 'UTF-8' ),
		);
	}
}
