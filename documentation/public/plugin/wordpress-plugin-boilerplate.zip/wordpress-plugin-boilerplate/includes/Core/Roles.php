<?php
/**
 * POS Roles and Capabilities management.
 *
 * @package Readypos\Core
 * @since 1.0.0
 */

namespace Readypos\Core;

use Readypos\Traits\Base;

/**
 * Class Roles
 *
 * Handles creation and removal of custom POS roles (Cashier, POS Manager).
 *
 * @package Readypos\Core
 */
class Roles {

	use Base;

	/**
	 * Register custom POS roles.
	 *
	 * @return void
	 */
	public function register_roles() {
		// POS Cashier Role
		add_role(
			'pos_cashier',
			__( 'POS Cashier', 'ready-pos' ),
			array(
				'read'             => true,
				'use_pos'          => true,
				'edit_posts'       => false,
				'delete_posts'     => false,
				'publish_posts'    => false,
				'manage_options'   => false,
			)
		);

		// POS Manager Role
		add_role(
			'pos_manager',
			__( 'POS Manager', 'ready-pos' ),
			array(
				'read'               => true,
				'use_pos'            => true,
				'manage_pos'         => true,
				'view_pos_reports'   => true,
				'edit_posts'         => false,
				'delete_posts'       => false,
				'publish_posts'      => false,
				'manage_options'     => false,
			)
		);

		// Add POS capabilities to Administrator & Shop Manager
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( 'use_pos' );
			$admin->add_cap( 'manage_pos' );
			$admin->add_cap( 'view_pos_reports' );
		}

		$shop_manager = get_role( 'shop_manager' );
		if ( $shop_manager ) {
			$shop_manager->add_cap( 'use_pos' );
			$shop_manager->add_cap( 'manage_pos' );
			$shop_manager->add_cap( 'view_pos_reports' );
		}
	}

	/**
	 * Remove POS roles.
	 *
	 * @return void
	 */
	public function remove_roles() {
		remove_role( 'pos_cashier' );
		remove_role( 'pos_manager' );

		// Remove POS capabilities from Administrator & Shop Manager
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->remove_cap( 'use_pos' );
			$admin->remove_cap( 'manage_pos' );
			$admin->remove_cap( 'view_pos_reports' );
		}

		$shop_manager = get_role( 'shop_manager' );
		if ( $shop_manager ) {
			$shop_manager->remove_cap( 'use_pos' );
			$shop_manager->remove_cap( 'manage_pos' );
			$shop_manager->remove_cap( 'view_pos_reports' );
		}
	}
}
