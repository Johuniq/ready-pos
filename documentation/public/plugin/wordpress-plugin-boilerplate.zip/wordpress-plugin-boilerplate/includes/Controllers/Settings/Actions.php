<?php
/**
 * Settings and Outlet management actions for POS.
 *
 * @package Readypos\Controllers\Settings
 * @since 1.0.0
 */

namespace Readypos\Controllers\Settings;

use Readypos\Models\POSOutlet;
use Readypos\Models\POSRegister;

defined( 'ABSPATH' ) || exit;

/**
 * Class Actions
 *
 * Handles CRUD operations for POS settings, store outlets, and registers.
 *
 * @package Readypos\Controllers\Settings
 */
class Actions {

	/**
	 * Get POS general, receipt, and payment settings.
	 *
	 * @return \WP_REST_Response
	 */
	public function get() {
		$default_settings = array(
			'currency_symbol' => class_exists( 'WooCommerce' ) ? get_woocommerce_currency_symbol() : '$',
			'currency_code'   => class_exists( 'WooCommerce' ) ? get_woocommerce_currency() : 'USD',
			'tax_rates'       => $this->get_wc_tax_rates(),
			'receipt_logo'    => get_option( 'readypos_receipt_logo', '' ),
			'receipt_header'  => get_option( 'readypos_receipt_header', get_bloginfo( 'name' ) ),
			'receipt_footer'  => get_option( 'readypos_receipt_footer', 'Thank you for shopping with us!' ),
			'payment_cash'    => get_option( 'readypos_payment_cash', 'yes' ),
			'payment_card'    => get_option( 'readypos_payment_card', 'yes' ),
			'keyboard_status' => get_option( 'readypos_keyboard_status', 'yes' ),
			'print_barcode'   => get_option( 'readypos_print_barcode', 'yes' ),
			'cash_drawer_pulse' => get_option( 'readypos_cash_drawer_pulse', 'none' ),
			'receipt_paper_width' => get_option( 'readypos_receipt_paper_width', '80mm' ),
			'customer_display_message' => get_option( 'readypos_customer_display_message', 'Welcome to our store!' ),
			'max_discount_limit' => intval( get_option( 'readypos_max_discount_limit', '100' ) ),
			'pos_order_prefix' => get_option( 'readypos_pos_order_prefix', '' ),
			'onboarding_complete' => get_option( 'readypos_onboarding_complete', 'no' ),
		);

		return new \WP_REST_Response( $default_settings, 200 );
	}

	/**
	 * Update settings.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function update( \WP_REST_Request $request ) {
		$receipt_logo    = sanitize_text_field( $request->get_param( 'receipt_logo' ) );
		$receipt_header  = sanitize_text_field( $request->get_param( 'receipt_header' ) );
		$receipt_footer  = sanitize_text_field( $request->get_param( 'receipt_footer' ) );
		$payment_cash    = sanitize_text_field( $request->get_param( 'payment_cash' ) );
		$payment_card    = sanitize_text_field( $request->get_param( 'payment_card' ) );
		$keyboard_status = sanitize_text_field( $request->get_param( 'keyboard_status' ) );
		$print_barcode   = sanitize_text_field( $request->get_param( 'print_barcode' ) );
		$cash_drawer_pulse = sanitize_text_field( $request->get_param( 'cash_drawer_pulse' ) );
		$receipt_paper_width = sanitize_text_field( $request->get_param( 'receipt_paper_width' ) );
		$customer_display_message = sanitize_text_field( $request->get_param( 'customer_display_message' ) );
		$max_discount_limit = intval( $request->get_param( 'max_discount_limit' ) );
		$pos_order_prefix = sanitize_text_field( $request->get_param( 'pos_order_prefix' ) );

		update_option( 'readypos_receipt_logo', $receipt_logo );
		update_option( 'readypos_receipt_header', $receipt_header );
		update_option( 'readypos_receipt_footer', $receipt_footer );
		update_option( 'readypos_payment_cash', $payment_cash );
		update_option( 'readypos_payment_card', $payment_card );
		update_option( 'readypos_keyboard_status', $keyboard_status );
		update_option( 'readypos_print_barcode', $print_barcode );
		update_option( 'readypos_cash_drawer_pulse', $cash_drawer_pulse );
		update_option( 'readypos_receipt_paper_width', $receipt_paper_width ?: '80mm' );
		update_option( 'readypos_customer_display_message', $customer_display_message ?: 'Welcome to our store!' );
		update_option( 'readypos_max_discount_limit', $max_discount_limit ?: 100 );
		update_option( 'readypos_pos_order_prefix', $pos_order_prefix );

		// Onboarding flag.
		$onboarding_complete = sanitize_text_field( $request->get_param( 'onboarding_complete' ) );
		if ( ! empty( $onboarding_complete ) ) {
			update_option( 'readypos_onboarding_complete', $onboarding_complete );
		}

		return new \WP_REST_Response( array( 'success' => true ), 200 );
	}

	/**
	 * Get outlets with registers.
	 *
	 * @return \WP_REST_Response
	 */
	public function get_outlets() {
		$outlets = POSOutlet::all();
		$data    = array();

		foreach ( $outlets as $outlet ) {
			$registers = POSRegister::where( 'outlet_id', $outlet->id )->get();
			$regs      = array();

			foreach ( $registers as $reg ) {
				$regs[] = array(
					'id'     => $reg->id,
					'name'   => $reg->name,
					'status' => $reg->status,
				);
			}

			$data[] = array(
				'id'             => $outlet->id,
				'name'           => $outlet->name,
				'address'        => $outlet->address,
				'phone'          => $outlet->phone,
				'email'          => $outlet->email,
				'receipt_header' => $outlet->receipt_header,
				'receipt_footer' => $outlet->receipt_footer,
				'status'         => $outlet->status,
				'registers'      => $regs,
			);
		}

		return new \WP_REST_Response( $data, 200 );
	}

	/**
	 * Create an outlet.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function create_outlet( \WP_REST_Request $request ) {
		$name           = sanitize_text_field( $request->get_param( 'name' ) );
		$address        = sanitize_text_field( $request->get_param( 'address' ) );
		$phone          = sanitize_text_field( $request->get_param( 'phone' ) );
		$email          = sanitize_email( $request->get_param( 'email' ) );
		$receipt_header = sanitize_text_field( $request->get_param( 'receipt_header' ) );
		$receipt_footer = sanitize_text_field( $request->get_param( 'receipt_footer' ) );

		$outlet = POSOutlet::create(
			array(
				'name'           => $name,
				'address'        => $address,
				'phone'          => $phone,
				'email'          => $email,
				'receipt_header' => $receipt_header,
				'receipt_footer' => $receipt_footer,
				'status'         => 'active',
			)
		);

		// Also create a default register for it
		POSRegister::create(
			array(
				'outlet_id' => $outlet->id,
				'name'      => __( 'Register 1', 'ready-pos' ),
				'status'    => 'closed',
			)
		);

		return new \WP_REST_Response( array( 'success' => true, 'id' => $outlet->id ), 200 );
	}

	/**
	 * Update an outlet.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function update_outlet( \WP_REST_Request $request ) {
		$id             = intval( $request->get_param( 'id' ) );
		$name           = sanitize_text_field( $request->get_param( 'name' ) );
		$address        = sanitize_text_field( $request->get_param( 'address' ) );
		$phone          = sanitize_text_field( $request->get_param( 'phone' ) );
		$email          = sanitize_email( $request->get_param( 'email' ) );
		$receipt_header = sanitize_text_field( $request->get_param( 'receipt_header' ) );
		$receipt_footer = sanitize_text_field( $request->get_param( 'receipt_footer' ) );

		$outlet = POSOutlet::find( $id );
		if ( ! $outlet ) {
			return new \WP_Error( 'not_found', __( 'Outlet not found.', 'ready-pos' ), array( 'status' => 404 ) );
		}

		$outlet->name           = $name;
		$outlet->address        = $address;
		$outlet->phone          = $phone;
		$outlet->email          = $email;
		$outlet->receipt_header = $receipt_header;
		$outlet->receipt_footer = $receipt_footer;
		$outlet->save();

		return new \WP_REST_Response( array( 'success' => true ), 200 );
	}

	/**
	 * Get WooCommerce tax rates.
	 *
	 * @return array
	 */
	private function get_wc_tax_rates() {
		if ( ! class_exists( 'WC_Tax' ) ) {
			return array();
		}

		$tax_classes   = \WC_Tax::get_tax_classes();
		$classes       = array_merge( array( '' ), $tax_classes );
		$formatted_rates = array();

		foreach ( $classes as $class ) {
			$rates = \WC_Tax::get_rates_for_tax_class( $class );
			foreach ( $rates as $rate ) {
				$formatted_rates[] = array(
					'id'    => $rate->tax_rate_id,
					'name'  => $rate->tax_rate_name,
					'rate'  => floatval( $rate->tax_rate ),
					'class' => $class ?: 'standard',
				);
			}
		}

		return $formatted_rates;
	}
}
