<?php
/**
 * POS Reports and Analytics actions.
 *
 * @package Readypos\Controllers\Reports
 * @since 1.0.0
 */

namespace Readypos\Controllers\Reports;

use Readypos\Models\POSOrderMeta;
use Readypos\Models\POSSession;
use Prappo\WpEloquent\Database\Capsule\Manager as Capsule;

defined( 'ABSPATH' ) || exit;

/**
 * Class Actions
 *
 * Handles analytics and reporting details for the POS admin dashboard.
 *
 * @package Readypos\Controllers\Reports
 */
class Actions {

	/**
	 * Retrieve a summary of sales (gross, orders, discount, tax) for a given date range.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function sales_summary( \WP_REST_Request $request ) {
		$days = $request->get_param( 'days' ) ? intval( $request->get_param( 'days' ) ) : 30;

		$start_date = date( 'Y-m-d 00:00:00', strtotime( "-{$days} days" ) );
		$end_date   = date( 'Y-m-d 23:59:59' );

		// Query POS Order metas in the range
		$order_metas = POSOrderMeta::where( 'created_at', '>=', $start_date )
			->where( 'created_at', '<=', $end_date )
			->get();

		$gross_sales  = 0;
		$total_orders = 0;
		$total_tax    = 0;
		$total_disc   = 0;

		$daily_chart = array();
		// Initialise daily chart array
		for ( $i = $days; $i >= 0; $i-- ) {
			$date = date( 'Y-m-d', strtotime( "-{$i} days" ) );
			$daily_chart[ $date ] = 0;
		}

		foreach ( $order_metas as $meta ) {
			$wc_order = wc_get_order( $meta->wc_order_id );
			if ( $wc_order ) {
				$total = floatval( $wc_order->get_total() );
				$gross_sales  += $total;
				$total_tax    += floatval( $wc_order->get_total_tax() );
				$total_disc   += floatval( $wc_order->get_discount_total() );
				$total_orders += 1;

				$order_date = date( 'Y-m-d', strtotime( $meta->created_at ) );
				if ( isset( $daily_chart[ $order_date ] ) ) {
					$daily_chart[ $order_date ] += $total;
				}
			}
		}

		$chart_data = array();
		foreach ( $daily_chart as $date => $amount ) {
			$chart_data[] = array(
				'date'  => date( 'M d', strtotime( $date ) ),
				'sales' => $amount,
			);
		}

		return new \WP_REST_Response(
			array(
				'summary' => array(
					'gross_sales'  => $gross_sales,
					'total_orders' => $total_orders,
					'total_tax'    => $total_tax,
					'total_disc'   => $total_disc,
					'net_sales'    => $gross_sales - $total_tax,
				),
				'chart'   => $chart_data,
			),
			200
		);
	}

	/**
	 * Get top selling products.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function product_performance( \WP_REST_Request $request ) {
		$days       = $request->get_param( 'days' ) ? intval( $request->get_param( 'days' ) ) : 30;
		$start_date = date( 'Y-m-d 00:00:00', strtotime( "-{$days} days" ) );

		// Fetch POS order IDs
		$order_ids = POSOrderMeta::where( 'created_at', '>=', $start_date )
			->pluck( 'wc_order_id' )
			->toArray();

		if ( empty( $order_ids ) ) {
			return new \WP_REST_Response( array(), 200 );
		}

		global $wpdb;
		$order_ids_str = implode( ',', array_map( 'intval', $order_ids ) );

		// Query to get quantities and totals by product
		$results = $wpdb->get_results( "
			SELECT 
				order_item_meta.meta_value as product_id,
				order_items.order_item_name as product_name,
				SUM(order_item_meta_qty.meta_value) as quantity,
				SUM(order_item_meta_total.meta_value) as total
			FROM {$wpdb->prefix}woocommerce_order_items as order_items
			LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta 
				ON order_items.order_item_id = order_item_meta.order_item_id 
				AND order_item_meta.meta_key = '_product_id'
			LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta_qty 
				ON order_items.order_item_id = order_item_meta_qty.order_item_id 
				AND order_item_meta_qty.meta_key = '_qty'
			LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta_total 
				ON order_items.order_item_id = order_item_meta_total.order_item_id 
				AND order_item_meta_total.meta_key = '_line_total'
			WHERE order_items.order_id IN ($order_ids_str)
			GROUP BY product_id
			ORDER BY quantity DESC
			LIMIT 10
		" );

		$products = array();
		foreach ( $results as $row ) {
			if ( empty( $row->product_id ) ) {
				continue;
			}
			$products[] = array(
				'id'       => intval( $row->product_id ),
				'name'     => $row->product_name,
				'quantity' => intval( $row->quantity ),
				'total'    => floatval( $row->total ),
			);
		}

		return new \WP_REST_Response( $products, 200 );
	}

	/**
	 * Get breakdown by cashier.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function cashier_performance( \WP_REST_Request $request ) {
		$days       = $request->get_param( 'days' ) ? intval( $request->get_param( 'days' ) ) : 30;
		$start_date = date( 'Y-m-d 00:00:00', strtotime( "-{$days} days" ) );

		$performers = POSOrderMeta::where( 'created_at', '>=', $start_date )
			->select( 'cashier_id', Capsule::raw( 'COUNT(id) as orders_count' ) )
			->groupBy( 'cashier_id' )
			->get();

		$data = array();
		foreach ( $performers as $perf ) {
			$user  = get_userdata( $perf->cashier_id );
			$metas = POSOrderMeta::where( 'cashier_id', $perf->cashier_id )
				->where( 'created_at', '>=', $start_date )
				->get();

			$total_sales = 0;
			foreach ( $metas as $meta ) {
				$order = wc_get_order( $meta->wc_order_id );
				if ( $order ) {
					$total_sales += floatval( $order->get_total() );
				}
			}

			$data[] = array(
				'name'   => $user ? $user->display_name : __( 'Unknown', 'ready-pos' ),
				'orders' => intval( $perf->orders_count ),
				'sales'  => $total_sales,
			);
		}

		return new \WP_REST_Response( $data, 200 );
	}

	/**
	 * Get payments methods breakdown.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function payment_methods( \WP_REST_Request $request ) {
		$days       = $request->get_param( 'days' ) ? intval( $request->get_param( 'days' ) ) : 30;
		$start_date = date( 'Y-m-d 00:00:00', strtotime( "-{$days} days" ) );

		$methods = POSOrderMeta::where( 'created_at', '>=', $start_date )
			->select( 'payment_method', Capsule::raw( 'COUNT(id) as count' ) )
			->groupBy( 'payment_method' )
			->get();

		$data = array();
		foreach ( $methods as $item ) {
			$metas = POSOrderMeta::where( 'payment_method', $item->payment_method )
				->where( 'created_at', '>=', $start_date )
				->get();

			$total_sales = 0;
			foreach ( $metas as $meta ) {
				$order = wc_get_order( $meta->wc_order_id );
				if ( $order ) {
					$total_sales += floatval( $order->get_total() );
				}
			}

			$data[] = array(
				'method' => ucfirst( $item->payment_method ),
				'count'  => intval( $item->count ),
				'sales'  => $total_sales,
			);
		}

		return new \WP_REST_Response( $data, 200 );
	}
}
