<?php
/**
 * Coupon-related POS actions.
 *
 * @package Readypos\Controllers\Coupons
 * @since 1.0.0
 */

namespace Readypos\Controllers\Coupons;

defined( 'ABSPATH' ) || exit;

/**
 * Class Actions
 *
 * Handles API actions for validating WooCommerce coupons at POS.
 *
 * @package Readypos\Controllers\Coupons
 */
class Actions {

	/**
	 * Validate a coupon code against WooCommerce.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function validate( \WP_REST_Request $request ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new \WP_Error( 'wc_missing', __( 'WooCommerce is not active.', 'ready-pos' ), array( 'status' => 500 ) );
		}

		$code = $request->get_param( 'code' ) ? sanitize_text_field( $request->get_param( 'code' ) ) : '';

		if ( empty( $code ) ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Coupon code cannot be empty.', 'ready-pos' ),
				),
				200
			);
		}

		$coupon = new \WC_Coupon( $code );

		if ( ! $coupon->get_id() ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Coupon does not exist.', 'ready-pos' ),
				),
				200
			);
		}

		// Perform basic validations (expiry, active states)
		$now = current_time( 'timestamp', true );

		// Check expiry
		$expiry = $coupon->get_date_expires();
		if ( $expiry && $expiry->getTimestamp() < $now ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'This coupon has expired.', 'ready-pos' ),
				),
				200
			);
		}

		// Check usage limit
		$usage_limit = $coupon->get_usage_limit();
		$usage_count = $coupon->get_usage_count();
		if ( $usage_limit > 0 && $usage_count >= $usage_limit ) {
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Coupon usage limit has been reached.', 'ready-pos' ),
				),
				200
			);
		}

		// Return coupon parameters for terminal checkout cart validation
		return new \WP_REST_Response(
			array(
				'success'                     => true,
				'code'                        => $coupon->get_code(),
				'amount'                      => floatval( $coupon->get_amount() ),
				'discount_type'               => $coupon->get_discount_type(),
				'description'                 => $coupon->get_description(),
				'minimum_amount'              => floatval( $coupon->get_minimum_amount() ),
				'maximum_amount'              => floatval( $coupon->get_maximum_amount() ),
				'individual_use'              => $coupon->get_individual_use(),
				'product_ids'                 => $coupon->get_product_ids(),
				'excluded_product_ids'        => $coupon->get_excluded_product_ids(),
				'product_categories'          => $coupon->get_product_categories(),
				'excluded_product_categories' => $coupon->get_excluded_product_categories(),
			),
			200
		);
	}
}
