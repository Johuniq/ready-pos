<?php
/**
 * Order-related POS actions.
 *
 * @package Readypos\Controllers\Orders
 * @since 1.0.0
 */

namespace Readypos\Controllers\Orders;

use Readypos\Models\POSOrderMeta;
use Readypos\Models\POSSession;
use Readypos\Models\POSOutletStock;
use Readypos\Models\POSCustomer;

defined( 'ABSPATH' ) || exit;

/**
 * Class Actions
 *
 * Handles API requests for creating POS orders, processing checkout, refunding, and parking carts.
 *
 * @package Readypos\Controllers\Orders
 */
class Actions {

	/**
	 * Create a new WooCommerce order from POS cart data.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function create( \WP_REST_Request $request ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new \WP_Error( 'wc_missing', __( 'WooCommerce is not active.', 'ready-pos' ), array( 'status' => 500 ) );
		}

		$items           = $request->get_param( 'items' ); // Cart items array
		$customer_id     = $request->get_param( 'customerId' ); // WP User ID or null
		$payment_method  = $request->get_param( 'paymentMethod' ); // 'cash', 'card', 'split', 'gift_card'
		$cash_received   = $request->get_param( 'cashReceived' );
		$change_given    = $request->get_param( 'changeGiven' );
		$discount_type   = $request->get_param( 'discountType' ); // 'fixed' or 'percent' or null
		$discount_value  = $request->get_param( 'discountValue' );
		$session_id      = $request->get_param( 'sessionId' );
		$notes           = $request->get_param( 'notes' );
		$split_payments  = $request->get_param( 'splitPayments' ); // Array of breakdowns when paymentMethod === 'split'

		if ( empty( $items ) || ! is_array( $items ) ) {
			return new \WP_Error( 'empty_cart', __( 'Cart is empty.', 'ready-pos' ), array( 'status' => 400 ) );
		}

		try {
			// Initialize WooCommerce order
			$order = wc_create_order();

			// Add products to order
			foreach ( $items as $item ) {
				$product_id = intval( $item['id'] );
				$quantity   = intval( $item['quantity'] );
				$product    = wc_get_product( $product_id );

				if ( ! $product ) {
					continue;
				}

				// If variation, we add the product using both item ID and parent ID
				if ( $product->is_type( 'variation' ) ) {
					$order->add_product( $product, $quantity, array(
						'variation' => $product->get_variation_attributes(),
					) );
				} else {
					$order->add_product( $product, $quantity );
				}
			}

			// Assign customer if provided
			if ( ! empty( $customer_id ) ) {
				$order->set_customer_id( intval( $customer_id ) );

				// Fetch customer billing info to auto-fill
				$user = get_userdata( $customer_id );
				if ( $user ) {
					$order->set_billing_first_name( $user->first_name ?: $user->display_name );
					$order->set_billing_last_name( $user->last_name );
					$order->set_billing_email( $user->user_email );
				}
			} else {
				// Default to Guest Customer
				$order->set_billing_first_name( 'POS' );
				$order->set_billing_last_name( 'Guest' );
			}

			// Handle discount if applied to cart
			if ( ! empty( $discount_value ) && floatval( $discount_value ) > 0 ) {
				if ( 'percent' === $discount_type ) {
					// We can apply cart discount
					$discount_amount = ( $order->get_subtotal() * floatval( $discount_value ) ) / 100;
				} else {
					$discount_amount = floatval( $discount_value );
				}

				// Add discount as negative fee
				$item = new \WC_Order_Item_Fee();
				$item->set_name( __( 'POS Discount', 'ready-pos' ) );
				$item->set_amount( -1 * $discount_amount );
				$item->set_total( -1 * $discount_amount );
				$order->add_item( $item );
			}

			// Set Payment Method details
			$order->set_payment_method( $payment_method );
			$order->set_payment_method_title( ucfirst( $payment_method ) . ' (POS)' );

			// Add cashier info
			$current_user_id = get_current_user_id();
			$order->add_meta_data( '_readypos_cashier_id', $current_user_id );
			$order->add_meta_data( '_readypos_is_pos_order', 'yes' );

			// Store split payment breakdown when applicable.
			if ( 'split' === $payment_method && is_array( $split_payments ) && ! empty( $split_payments ) ) {
				$sanitized_breakdown = array();
				foreach ( $split_payments as $sp ) {
					$sanitized_breakdown[] = array(
						'method' => sanitize_text_field( $sp['method'] ?? '' ),
						'amount' => floatval( $sp['amount'] ?? 0 ),
						'ref'    => sanitize_text_field( $sp['ref'] ?? '' ),
					);
				}
				$order->add_meta_data( '_readypos_split_payments', wp_json_encode( $sanitized_breakdown ) );

				// Also append a human-readable breakdown to the order note.
				$breakdown_lines = array();
				foreach ( $sanitized_breakdown as $sp ) {
					$breakdown_lines[] = sprintf(
						'%s: %s%s',
						ucfirst( str_replace( '_', ' ', $sp['method'] ) ),
						wc_price( $sp['amount'] ),
						! empty( $sp['ref'] ) ? ' (' . $sp['ref'] . ')' : ''
					);
				}
				$order->add_order_note(
					__( 'Split Payment Breakdown:', 'ready-pos' ) . "\n" . implode( "\n", $breakdown_lines )
				);
			}

			if ( ! empty( $notes ) ) {
				$order->add_order_note( $notes );
				$order->set_customer_note( $notes );
			}

			// Calculate totals and save
			$order->calculate_totals();
			$order->update_status( 'completed', __( 'Order completed via POS terminal.', 'ready-pos' ) );
			$order->save();

			$order_id = $order->get_id();

			// Store POS Order Metadata in our custom table
			POSOrderMeta::create(
				array(
					'wc_order_id'    => $order_id,
					'session_id'     => $session_id ? intval( $session_id ) : null,
					'cashier_id'     => $current_user_id,
					'customer_id'    => $customer_id ? intval( $customer_id ) : null,
					'payment_method' => $payment_method,
					'cash_received'  => $cash_received ? floatval( $cash_received ) : null,
					'change_given'   => $change_given ? floatval( $change_given ) : null,
					'discount_type'  => $discount_type,
					'discount_value' => $discount_value ? floatval( $discount_value ) : null,
					'order_status'   => 'completed',
					'notes'          => $notes,
				)
			);

			// Update session sales metrics if session is active
			if ( $session_id ) {
				$session = POSSession::find( $session_id );
				if ( $session && 'open' === $session->status ) {
					$session->total_sales  += $order->get_total();
					$session->total_orders += 1;
					if ( 'cash' === $payment_method ) {
						$session->cash_total += $order->get_total();
					} elseif ( 'card' === $payment_method ) {
						$session->card_total += $order->get_total();
					} elseif ( 'split' === $payment_method && is_array( $split_payments ) ) {
						foreach ( $split_payments as $sp ) {
							$amt = floatval( $sp['amount'] ?? 0 );
							if ( 'cash' === ( $sp['method'] ?? '' ) ) {
								$session->cash_total += $amt;
							} elseif ( 'card' === ( $sp['method'] ?? '' ) ) {
								$session->card_total += $amt;
							}
						}
					}
					$session->save();

					// Decrement outlet-specific stock for each item
					if ( $session->outlet_id ) {
						foreach ( $items as $item ) {
							$product_id = intval( $item['id'] );
							$quantity   = intval( $item['quantity'] );

							$outlet_stock = POSOutletStock::where( 'outlet_id', $session->outlet_id )
								->where( 'product_id', $product_id )
								->first();

							if ( $outlet_stock ) {
								$outlet_stock->stock_quantity = max( 0, floatval( $outlet_stock->stock_quantity ) - $quantity );
								$outlet_stock->save();
							}
						}
					}
				}
			}

			// Award loyalty points to customer (1 point per $1 spent).
			if ( ! empty( $customer_id ) ) {
				$pos_customer = POSCustomer::where( 'wc_customer_id', intval( $customer_id ) )->first();
				if ( $pos_customer ) {
					$points_earned = (int) floor( floatval( $order->get_total() ) );
					$pos_customer->loyalty_points += $points_earned;
					$pos_customer->total_spent    += floatval( $order->get_total() );
					$pos_customer->visit_count    += 1;
					$pos_customer->save();
				}
			}

			return new \WP_REST_Response(
				array(
					'success'  => true,
					'order_id' => $order_id,
					'total'    => floatval( $order->get_total() ),
				),
				200
			);

		} catch ( \Exception $e ) {
			return new \WP_Error( 'checkout_failed', $e->getMessage(), array( 'status' => 500 ) );
		}
	}

	/**
	 * Get POS order history.
	 *
	 * @param \WP_REST_Request $request REST request object.
	 * @return \WP_REST_Response
	 */
	public function get( \WP_REST_Request $request ) {
		$limit = $request->get_param( 'limit' ) ? intval( $request->get_param( 'limit' ) ) : 20;
		$page  = $request->get_param( 'page' ) ? intval( $request->get_param( 'page' ) ) : 1;

		// Fetch order IDs from custom POS meta table
		$query = POSOrderMeta::orderBy( 'created_at', 'desc' );

		$total = $query->count();
		$metas = $query->skip( ( $page - 1 ) * $limit )->take( $limit )->get();

		$orders = array();
		foreach ( $metas as $meta ) {
			$wc_order = wc_get_order( $meta->wc_order_id );
			if ( $wc_order ) {
				$cashier = get_userdata( $meta->cashier_id );

				$orders[] = array(
					'id'             => $meta->wc_order_id,
					'order_number'   => $wc_order->get_order_number(),
					'total'          => floatval( $wc_order->get_total() ),
					'payment_method' => $meta->payment_method,
					'cashier_name'   => $cashier ? $cashier->display_name : __( 'Unknown', 'ready-pos' ),
					'date'           => $meta->created_at->toDateTimeString(),
					'status'         => $wc_order->get_status(),
				);
			}
		}

		return new \WP_REST_Response(
			array(
				'orders'      => $orders,
				'total'       => $total,
				'total_pages' => ceil( $total / $limit ),
			),
			200
		);
	}

	/**
	 * Get details of a single order.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_detail( \WP_REST_Request $request ) {
		$order_id = intval( $request->get_param( 'id' ) );
		$wc_order = wc_get_order( $order_id );

		if ( ! $wc_order ) {
			return new \WP_Error( 'not_found', __( 'Order not found.', 'ready-pos' ), array( 'status' => 404 ) );
		}

		$pos_meta = POSOrderMeta::where( 'wc_order_id', $order_id )->first();
		$items    = array();

		foreach ( $wc_order->get_items() as $item_id => $item ) {
			$items[] = array(
				'name'     => $item->get_name(),
				'quantity' => $item->get_quantity(),
				'total'    => floatval( $item->get_total() ),
			);
		}

		$details = array(
			'id'             => $order_id,
			'order_number'   => $wc_order->get_order_number(),
			'items'          => $items,
			'subtotal'       => floatval( $wc_order->get_subtotal() ),
			'total'          => floatval( $wc_order->get_total() ),
			'discount'       => floatval( $wc_order->get_discount_total() ),
			'tax'            => floatval( $wc_order->get_total_tax() ),
			'payment_method' => $pos_meta ? $pos_meta->payment_method : $wc_order->get_payment_method(),
			'cash_received'  => $pos_meta ? floatval( $pos_meta->cash_received ) : 0,
			'change_given'   => $pos_meta ? floatval( $pos_meta->change_given ) : 0,
			'date'           => $wc_order->get_date_created()->date( 'Y-m-d H:i:s' ),
			'status'         => $wc_order->get_status(),
			'notes'          => $wc_order->get_customer_note(),
		);

		return new \WP_REST_Response( $details, 200 );
	}

	/**
	 * Process partial/full refund.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function refund( \WP_REST_Request $request ) {
		$order_id = intval( $request->get_param( 'orderId' ) );
		$amount   = floatval( $request->get_param( 'amount' ) );
		$reason   = $request->get_param( 'reason' ) ? sanitize_text_field( $request->get_param( 'reason' ) ) : '';

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new \WP_Error( 'not_found', __( 'Order not found.', 'ready-pos' ), array( 'status' => 404 ) );
		}

		try {
			$refund = wc_create_refund( array(
				'amount'         => $amount,
				'reason'         => $reason,
				'order_id'       => $order_id,
				'refund_payment' => false, // Manual POS refund
			) );

			if ( is_wp_error( $refund ) ) {
				return $refund;
			}

			// Adjust POS session refunds if session metadata exists
			$pos_meta = POSOrderMeta::where( 'wc_order_id', $order_id )->first();
			if ( $pos_meta && $pos_meta->session_id ) {
				$session = POSSession::find( $pos_meta->session_id );
				if ( $session && 'open' === $session->status ) {
					$session->total_refunds += $amount;
					$session->save();
				}
			}

			return new \WP_REST_Response( array( 'success' => true ), 200 );

		} catch ( \Exception $e ) {
			return new \WP_Error( 'refund_failed', $e->getMessage(), array( 'status' => 500 ) );
		}
	}

	/**
	 * Park/Hold a cart session.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function hold( \WP_REST_Request $request ) {
		$cashier_id = get_current_user_id();
		$cart_data  = $request->get_param( 'cart' ); // JSON/Array of cart items + customer
		$hold_id    = $request->get_param( 'holdId' ) ?: uniqid( 'hold_' );

		$held_orders = get_transient( 'readypos_held_orders_' . $cashier_id ) ?: array();
		$held_orders[ $hold_id ] = array(
			'id'        => $hold_id,
			'cart'      => $cart_data,
			'parked_at' => current_time( 'mysql' ),
		);

		set_transient( 'readypos_held_orders_' . $cashier_id, $held_orders, DAY_IN_SECONDS * 7 );

		return new \WP_REST_Response( array( 'success' => true, 'holdId' => $hold_id ), 200 );
	}

	/**
	 * Get all parked/held orders for the current cashier.
	 *
	 * @return \WP_REST_Response
	 */
	public function get_held() {
		$cashier_id  = get_current_user_id();
		$held_orders = get_transient( 'readypos_held_orders_' . $cashier_id ) ?: array();

		return new \WP_REST_Response( array_values( $held_orders ), 200 );
	}

	/**
	 * Resume or delete a parked order.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function resume( \WP_REST_Request $request ) {
		$cashier_id  = get_current_user_id();
		$hold_id     = $request->get_param( 'holdId' );
		$held_orders = get_transient( 'readypos_held_orders_' . $cashier_id ) ?: array();

		if ( isset( $held_orders[ $hold_id ] ) ) {
			$order = $held_orders[ $hold_id ];
			unset( $held_orders[ $hold_id ] );
			set_transient( 'readypos_held_orders_' . $cashier_id, $held_orders, DAY_IN_SECONDS * 7 );
			return new \WP_REST_Response( $order, 200 );
		}

		return new \WP_REST_Response( null, 404 );
	}
}
