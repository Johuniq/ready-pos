<?php
/**
 * Register Session actions for POS.
 *
 * @package Readypos\Controllers\Sessions
 * @since 1.0.0
 */

namespace Readypos\Controllers\Sessions;

use Readypos\Models\POSSession;
use Readypos\Models\POSRegister;

defined( 'ABSPATH' ) || exit;

/**
 * Class Actions
 *
 * Handles opening, closing, and tracking active register sessions.
 *
 * @package Readypos\Controllers\Sessions
 */
class Actions {

	/**
	 * Open a register session.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function open( \WP_REST_Request $request ) {
		$user_id      = get_current_user_id();
		$register_id  = intval( $request->get_param( 'registerId' ) );
		$outlet_id    = intval( $request->get_param( 'outletId' ) );
		$opening_cash = floatval( $request->get_param( 'openingCash' ) );
		$notes        = sanitize_text_field( $request->get_param( 'notes' ) );

		if ( empty( $register_id ) || empty( $outlet_id ) ) {
			return new \WP_Error( 'missing_fields', __( 'Outlet ID and Register ID are required.', 'ready-pos' ), array( 'status' => 400 ) );
		}

		// Check if register is already open
		$active_session = POSSession::where( 'register_id', $register_id )
			->where( 'status', 'open' )
			->first();

		if ( $active_session ) {
			return new \WP_Error( 'already_open', __( 'This register is already open in another session.', 'ready-pos' ), array( 'status' => 400 ) );
		}

		// Create session
		$session = POSSession::create(
			array(
				'user_id'       => $user_id,
				'outlet_id'     => $outlet_id,
				'register_id'   => $register_id,
				'opening_cash'  => $opening_cash,
				'total_sales'   => 0,
				'total_orders'  => 0,
				'total_refunds' => 0,
				'cash_total'    => 0,
				'card_total'    => 0,
				'status'        => 'open',
				'notes'         => $notes,
				'opened_at'     => current_time( 'mysql' ),
			)
		);

		// Update register status
		POSRegister::where( 'id', $register_id )->update( array( 'status' => 'open' ) );

		return new \WP_REST_Response(
			array(
				'success'    => true,
				'session_id' => $session->id,
			),
			200
		);
	}

	/**
	 * Close register session.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function close( \WP_REST_Request $request ) {
		$session_id   = intval( $request->get_param( 'sessionId' ) );
		$closing_cash = floatval( $request->get_param( 'closingCash' ) );
		$notes        = sanitize_text_field( $request->get_param( 'notes' ) );

		$session = POSSession::find( $session_id );
		if ( ! $session || 'closed' === $session->status ) {
			return new \WP_Error( 'invalid_session', __( 'Active session not found or already closed.', 'ready-pos' ), array( 'status' => 400 ) );
		}

		// Close session and update stats
		$session->closing_cash = $closing_cash;
		$session->status       = 'closed';
		$session->notes        = empty( $notes ) ? $session->notes : $session->notes . "\nClose notes: " . $notes;
		$session->closed_at    = current_time( 'mysql' );
		$session->save();

		// Update register status
		POSRegister::where( 'id', $session->register_id )->update( array( 'status' => 'closed' ) );

		return new \WP_REST_Response( array( 'success' => true ), 200 );
	}

	/**
	 * Get current active session for the logged in user or register.
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response
	 */
	public function current( \WP_REST_Request $request ) {
		$user_id = get_current_user_id();

		$session = POSSession::where( 'user_id', $user_id )
			->where( 'status', 'open' )
			->first();

		if ( $session ) {
			return new \WP_REST_Response(
				array(
					'has_active' => true,
					'session'    => array(
						'id'           => $session->id,
						'outlet_id'    => $session->outlet_id,
						'register_id'  => $session->register_id,
						'opening_cash' => floatval( $session->opening_cash ),
						'total_sales'  => floatval( $session->total_sales ),
						'total_orders' => intval( $session->total_orders ),
						'cash_total'   => floatval( $session->cash_total ),
						'card_total'   => floatval( $session->card_total ),
						'notes'        => $session->notes,
						'opened_at'    => $session->opened_at,
					),
				),
				200
			);
		}

		return new \WP_REST_Response( array( 'has_active' => false ), 200 );
	}

	/**
	 * Get session history.
	 *
	 * @return \WP_REST_Response
	 */
	public function history() {
		$sessions = POSSession::orderBy( 'opened_at', 'desc' )->take( 20 )->get();
		$history  = array();

		foreach ( $sessions as $session ) {
			$user     = get_userdata( $session->user_id );
			$register = POSRegister::find( $session->register_id );

			$history[] = array(
				'id'            => $session->id,
				'cashier'       => $user ? $user->display_name : __( 'Unknown', 'ready-pos' ),
				'register_name' => $register ? $register->name : __( 'Register', 'ready-pos' ),
				'opening_cash'  => floatval( $session->opening_cash ),
				'closing_cash'  => floatval( $session->closing_cash ),
				'total_sales'   => floatval( $session->total_sales ),
				'status'        => $session->status,
				'opened_at'     => $session->opened_at,
				'closed_at'     => $session->closed_at,
			);
		}

		return new \WP_REST_Response( $history, 200 );
	}

	/**
	 * Record a cash adjustment (Pay In / Pay Out).
	 *
	 * @param \WP_REST_Request $request REST request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function cash_adjustment( \WP_REST_Request $request ) {
		$session_id = intval( $request->get_param( 'sessionId' ) );
		$type       = sanitize_text_field( $request->get_param( 'type' ) ); // 'in' or 'out'
		$amount     = floatval( $request->get_param( 'amount' ) );
		$reason     = sanitize_text_field( $request->get_param( 'reason' ) );

		if ( empty( $session_id ) || empty( $type ) || $amount <= 0 ) {
			return new \WP_Error( 'missing_fields', __( 'Session ID, type, and valid amount are required.', 'ready-pos' ), array( 'status' => 400 ) );
		}

		$session = POSSession::find( $session_id );
		if ( ! $session || 'open' !== $session->status ) {
			return new \WP_Error( 'invalid_session', __( 'Active session not found.', 'ready-pos' ), array( 'status' => 400 ) );
		}

		// Adjust the cash total
		if ( 'in' === $type ) {
			$session->cash_total += $amount;
			$log_type = 'Pay In';
		} else {
			$session->cash_total -= $amount;
			$log_type = 'Pay Out';
		}

		// Format and append to notes
		$cashier_id = get_current_user_id();
		$time = current_time( 'mysql' );
		$log_entry = sprintf(
			"[%s] %s (Reason: %s, Cashier ID: %d, Time: %s)",
			$log_type,
			number_format( $amount, 2, '.', '' ),
			empty( $reason ) ? 'None' : $reason,
			$cashier_id,
			$time
		);

		$session->notes = empty( $session->notes ) ? $log_entry : $session->notes . "\n" . $log_entry;
		$session->save();

		return new \WP_REST_Response(
			array(
				'success'    => true,
				'cash_total' => floatval( $session->cash_total ),
				'notes'      => $session->notes,
			),
			200
		);
	}
}
