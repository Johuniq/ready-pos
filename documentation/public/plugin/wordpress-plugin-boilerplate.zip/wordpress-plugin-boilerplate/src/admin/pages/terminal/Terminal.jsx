import React, { useState, useEffect } from "react";
import { useAtom, useSetAtom } from "jotai";
import { 
    sessionAtom, 
    settingsAtom, 
    heldOrdersCountAtom,
    cartAtom,
    customerAtom,
    cartDiscountAmountAtom,
    cartTaxAmountAtom,
    cartSubtotalAtom,
    cartTotalAtom,
    cartCouponsAtom
} from "@/admin/stores/posStore";
import { api } from "@/lib/api";
import POSHeader from "./components/POSHeader";
import ProductGrid from "./components/ProductGrid";
import CartPanel from "./components/CartPanel";
import PaymentModal from "./components/PaymentModal";
import HeldCartsModal from "./components/HeldCartsModal";
import RegisterSessionModal from "./components/RegisterSessionModal";
import CameraScannerModal from "./components/CameraScannerModal";
import ShiftTrackerModal from "./components/ShiftTrackerModal";
import { useCart } from "@/admin/hooks/useCart";
import { dbOperations } from "@/admin/lib/db";
import { toast } from "sonner";

export default function Terminal() {
    const [session, setSession] = useAtom(sessionAtom);
    const setSettings = useSetAtom(settingsAtom);
    const setHeldCount = useSetAtom(heldOrdersCountAtom);
    const { addToCart } = useCart();

    // Read cart states to broadcast to customer-display
    const [cart] = useAtom(cartAtom);
    const [customer] = useAtom(customerAtom);
    const [discountAmount] = useAtom(cartDiscountAmountAtom);
    const [taxAmount] = useAtom(cartTaxAmountAtom);
    const [subtotal] = useAtom(cartSubtotalAtom);
    const [total] = useAtom(cartTotalAtom);
    const [coupons] = useAtom(cartCouponsAtom);
    const [settings] = useAtom(settingsAtom);

    // Sync state with Customer Display via BroadcastChannel
    useEffect(() => {
        const channel = new BroadcastChannel("readypos_customer_display");

        const broadcastState = () => {
            channel.postMessage({
                type: "SYNC_STATE",
                data: {
                    cart,
                    customer,
                    discountAmount,
                    taxAmount,
                    subtotal,
                    total,
                    coupons,
                    settings
                }
            });
        };

        // Broadcast current state on changes
        broadcastState();

        // Listen for REQUEST_STATE from new customer display windows
        const handleMessage = (event) => {
            if (event.data?.type === "REQUEST_STATE") {
                broadcastState();
            }
        };
        channel.addEventListener("message", handleMessage);

        return () => {
            channel.removeEventListener("message", handleMessage);
            channel.close();
        };
    }, [cart, customer, discountAmount, taxAmount, subtotal, total, coupons, settings]);

    // Modal Visibility States
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [showHeldCartsModal, setShowHeldCartsModal] = useState(false);
    const [showSessionModal, setShowSessionModal] = useState(false);
    const [showCameraScannerModal, setShowCameraScannerModal] = useState(false);
    const [showShiftModal, setShowShiftModal] = useState(false);
    const [sessionModalMode, setSessionModalMode] = useState("open"); // "open" or "close"
    
    // Shift Tracking States
    const [activeShift, setActiveShift] = useState(null);
    const [initializing, setInitializing] = useState(true);

    // Load initial settings and check shift & session status
    useEffect(() => {
        const initializePOS = async () => {
            try {
                // 1. Fetch settings (currency, tax, etc.)
                const settingsData = await api.get("/settings/get");
                if (settingsData) {
                    setSettings(settingsData);
                }

                // 2. Fetch active session
                const sessionData = await api.get("/sessions/current");
                setSession(sessionData || { has_active: false, session: null });

                // 2.5 Fetch active shift
                const shiftData = await api.get("/shifts/current");
                const hasShift = shiftData && shiftData.has_active;
                if (hasShift) {
                    setActiveShift(shiftData.shift);
                } else {
                    setActiveShift(null);
                    setShowShiftModal(true);
                }

                // 3. Fetch held count
                const heldData = await api.get("/orders/held");
                setHeldCount(heldData?.length || 0);

                // 4. Force session modal open if there's no active session AND shift is clocked in
                if ((!sessionData || !sessionData.has_active) && hasShift) {
                    setSessionModalMode("open");
                    setShowSessionModal(true);
                }
            } catch (err) {
                console.error("POS initialization failed", err);
                toast.error("Failed to load POS settings or session");
            } finally {
                setInitializing(false);
            }
        };

        initializePOS();
    }, [setSession, setSettings, setHeldCount]);

    // Sequential lock: force register session open once cashier is clocked in
    useEffect(() => {
        if (!initializing && activeShift && (!session || !session.has_active)) {
            setSessionModalMode("open");
            setShowSessionModal(true);
        }
    }, [activeShift, session?.has_active, initializing]);

    // Handle session button click in Header
    const handleOpenCloseSession = () => {
        if (session.has_active) {
            setSessionModalMode("close");
        } else {
            setSessionModalMode("open");
        }
        setShowSessionModal(true);
    };

    const handleCameraBarcodeScanned = async (code) => {
        toast.info(`Scanned barcode: ${code}`);
        try {
            let product = null;
            if (navigator.onLine) {
                product = await api.get("/products/search", { code });
            } else {
                const cached = await dbOperations.getAll("products");
                product = cached.find(p => p.sku === code || p.barcode === code);
            }

            if (product) {
                if (product.variations && product.variations.length > 0) {
                    toast.warning(`Product "${product.name}" has options. Please select them manually.`);
                } else {
                    addToCart(product, 1);
                    toast.success(`Added ${product.name} to cart`);
                }
            } else {
                toast.error("No product found matching this barcode");
            }
        } catch (err) {
            console.error("Barcode lookup error:", err);
            toast.error("Error searching barcode product");
        }
    };

    if (initializing) {
        return (
            <div className="w-screen h-screen flex flex-col items-center justify-center bg-background text-foreground gap-4">
                <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                <p className="text-sm font-semibold">Initializing POS Terminal...</p>
            </div>
        );
    }

    return (
        <div className="readypos-app w-screen h-screen flex flex-col overflow-hidden bg-background text-foreground">
            {/* Header */}
            <POSHeader 
                onOpenCloseSession={handleOpenCloseSession} 
                onOpenHeldCarts={() => setShowHeldCartsModal(true)} 
                onOpenCameraScanner={() => setShowCameraScannerModal(true)}
                onOpenShiftTracker={() => setShowShiftModal(true)}
                activeShift={activeShift}
            />

            {/* Main Terminal Workspace */}
            <div className="flex-1 flex overflow-hidden min-h-0">
                {/* Product Search & Grid Panel */}
                <div className="flex-1 flex flex-col overflow-hidden bg-muted/10">
                    <ProductGrid />
                </div>

                {/* Cart & Customer Panel */}
                <div className="w-96 shrink-0 flex flex-col border-l border-border bg-card">
                    <CartPanel 
                        onOpenPayment={() => setShowPaymentModal(true)} 
                        onOpenHeldCarts={() => setShowHeldCartsModal(true)} 
                    />
                </div>
            </div>

            {/* Modals */}
            <PaymentModal 
                open={showPaymentModal} 
                onOpenChange={setShowPaymentModal} 
            />

            <HeldCartsModal 
                open={showHeldCartsModal} 
                onOpenChange={setShowHeldCartsModal} 
            />

            <RegisterSessionModal 
                open={showSessionModal} 
                onOpenChange={setShowSessionModal}
                mode={sessionModalMode}
                onShiftChange={setActiveShift}
            />

            <CameraScannerModal 
                open={showCameraScannerModal} 
                onOpenChange={setShowCameraScannerModal} 
                onScan={handleCameraBarcodeScanned}
            />

            <ShiftTrackerModal 
                open={showShiftModal} 
                onOpenChange={setShowShiftModal}
                activeShift={activeShift}
                onShiftChange={setActiveShift}
                sessionId={session.session?.id}
            />
        </div>
    );
}
