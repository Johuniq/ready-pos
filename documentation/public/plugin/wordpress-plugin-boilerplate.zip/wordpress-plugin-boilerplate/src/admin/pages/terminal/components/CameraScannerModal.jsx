import React, { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Camera, RefreshCw, X, Loader2 } from "lucide-react";

export default function CameraScannerModal({ open, onOpenChange, onScan }) {
    const [cameras, setCameras] = useState([]);
    const [selectedCameraId, setSelectedCameraId] = useState("");
    const [isScanning, setIsScanning] = useState(false);
    const [errorMsg, setErrorMsg] = useState("");
    const scannerRef = useRef(null);
    const qrRegionId = "camera-scanner-viewport";

    // Play a nice high-fidelity beep sound on barcode match
    const playBeep = () => {
        try {
            const context = new (window.AudioContext || window.webkitAudioContext)();
            const osc = context.createOscillator();
            const gain = context.createGain();
            osc.connect(gain);
            gain.connect(context.destination);
            osc.type = "sine";
            osc.frequency.setValueAtTime(800, context.currentTime);
            gain.gain.setValueAtTime(0.3, context.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, context.currentTime + 0.15);
            osc.start();
            osc.stop(context.currentTime + 0.15);
        } catch (e) {
            console.error("Audio beep fail:", e);
        }
    };

    useEffect(() => {
        if (!open) {
            stopScanning();
            return;
        }

        Html5Qrcode.getCameras()
            .then((devices) => {
                if (devices && devices.length > 0) {
                    setCameras(devices);
                    // Default to back camera if found
                    const backCam = devices.find(d => d.label.toLowerCase().includes("back") || d.label.toLowerCase().includes("environment"));
                    setSelectedCameraId(backCam ? backCam.id : devices[0].id);
                } else {
                    setErrorMsg("No camera devices found.");
                }
            })
            .catch((err) => {
                console.error("Failed to get cameras:", err);
                setErrorMsg("Camera permission denied or not supported.");
            });

        return () => {
            stopScanning();
        };
    }, [open]);

    useEffect(() => {
        if (open && selectedCameraId) {
            startScanning(selectedCameraId);
        }
    }, [selectedCameraId, open]);

    const startScanning = async (cameraId) => {
        await stopScanning();

        const html5Qrcode = new Html5Qrcode(qrRegionId);
        scannerRef.current = html5Qrcode;
        setIsScanning(true);
        setErrorMsg("");

        try {
            await html5Qrcode.start(
                cameraId,
                {
                    fps: 15,
                    qrbox: (width, height) => {
                        const size = Math.min(width, height) * 0.7;
                        return { width: size, height: size * 0.65 };
                    },
                    aspectRatio: 1.0,
                },
                (decodedText) => {
                    playBeep();
                    onScan(decodedText);
                    onOpenChange(false);
                },
                () => {
                    // Frame scan failed, ignore verbose warnings
                }
            );
        } catch (err) {
            console.error("Failed to start html5Qrcode:", err);
            setErrorMsg("Failed to start camera feed. Please select another camera.");
            setIsScanning(false);
        }
    };

    const stopScanning = async () => {
        if (scannerRef.current && scannerRef.current.isScanning) {
            try {
                await scannerRef.current.stop();
            } catch (err) {
                console.error("Failed to stop scanner:", err);
            }
        }
        scannerRef.current = null;
        setIsScanning(false);
    };

    const handleSwitchCamera = () => {
        if (cameras.length <= 1) return;
        const currentIndex = cameras.findIndex(c => c.id === selectedCameraId);
        const nextIndex = (currentIndex + 1) % cameras.length;
        setSelectedCameraId(cameras[nextIndex].id);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-md rounded-2xl overflow-hidden border border-border/80 bg-background/95 backdrop-blur-md shadow-2xl">
                <DialogHeader className="flex flex-row justify-between items-center pb-2">
                    <DialogTitle className="text-sm font-extrabold text-foreground flex items-center gap-2">
                        <Camera className="w-4 h-4 text-primary animate-pulse" />
                        <span>Camera Barcode Scanner</span>
                    </DialogTitle>
                </DialogHeader>

                <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-black/90 border flex flex-col items-center justify-center">
                    <div id={qrRegionId} className="w-full h-full object-cover"></div>
                    
                    <div className="absolute inset-0 pointer-events-none border-2 border-primary/20 rounded-xl flex items-center justify-center">
                        <div className="w-3/4 h-0.5 bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-bounce" />
                    </div>

                    {!isScanning && !errorMsg && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-black/60 gap-3">
                            <Loader2 className="w-8 h-8 animate-spin text-primary" />
                            <p className="text-xs font-semibold">Initializing camera stream...</p>
                        </div>
                    )}

                    {errorMsg && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-black/85 p-6 text-center gap-3">
                            <span className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center text-destructive">
                                <X className="w-6 h-6" />
                            </span>
                            <p className="text-sm font-semibold">{errorMsg}</p>
                        </div>
                    )}
                </div>

                <div className="flex items-center justify-between mt-4">
                    <div className="text-xs font-medium text-muted-foreground truncate max-w-[200px]">
                        {cameras.find(c => c.id === selectedCameraId)?.label || "Default Camera"}
                    </div>

                    <div className="flex gap-2">
                        {cameras.length > 1 && (
                            <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={handleSwitchCamera}
                                className="h-8 text-xs font-bold gap-1.5"
                            >
                                <RefreshCw className="w-3.5 h-3.5" />
                                <span>Switch</span>
                            </Button>
                        )}
                        <Button
                            type="button"
                            variant="destructive"
                            size="sm"
                            onClick={() => onOpenChange(false)}
                            className="h-8 text-xs font-bold"
                        >
                            Close
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
