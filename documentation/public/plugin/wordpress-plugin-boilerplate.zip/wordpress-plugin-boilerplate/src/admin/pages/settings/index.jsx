import React, { useState, useEffect } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Settings as SettingsIcon, Printer, CreditCard, Keyboard, ShieldAlert, Percent, Tags, Tv } from "lucide-react";

export default function Settings() {
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);
    const [settings, setSettings] = useState({
        currency_symbol: "$",
        currency_code: "USD",
        receipt_logo: "",
        receipt_header: "",
        receipt_footer: "",
        payment_cash: "yes",
        payment_card: "yes",
        keyboard_status: "yes",
        print_barcode: "yes",
        cash_drawer_pulse: "none",
        receipt_paper_width: "80mm",
        customer_display_message: "Welcome to our store!",
        max_discount_limit: 100,
        pos_order_prefix: "",
    });

    useEffect(() => {
        const fetchSettings = async () => {
            setLoading(true);
            try {
                const data = await api.get("/settings/get");
                if (data) {
                    setSettings({
                        ...settings,
                        ...data,
                    });
                }
            } catch (err) {
                toast.error("Failed to load settings");
            } finally {
                setLoading(false);
            }
        };
        fetchSettings();
    }, []);

    const handleSave = async (e) => {
        if (e) e.preventDefault();
        setSaving(true);
        try {
            await api.post("/settings/update", settings);
            toast.success("Settings updated successfully");
        } catch (err) {
            toast.error(err.message || "Failed to update settings");
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="h-96 flex flex-col items-center justify-center gap-2">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs text-muted-foreground">Loading configurations...</p>
            </div>
        );
    }

    return (
        <div className="page-container bg-muted/20 min-h-screen pb-12">
            <div className="flex items-center justify-between">
                <div className="space-y-1">
                    <h2 className="page-title text-2xl font-bold flex items-center gap-2">
                        <SettingsIcon className="w-6 h-6 text-primary" />
                        <span>POS Configuration</span>
                    </h2>
                    <p className="page-subtitle text-xs text-muted-foreground">
                        Manage register behaviors, live receipt layout templates, maximum cashier discounts, and custom prefixes.
                    </p>
                </div>
            </div>

            <Separator className="my-6 opacity-40" />

            <form onSubmit={handleSave} className="space-y-6">
                <Tabs defaultValue="general" className="space-y-6">
                    <TabsList className="grid grid-cols-3 max-w-md bg-muted/10 border p-1 rounded-xl">
                        <TabsTrigger value="general" className="text-xs font-semibold rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-xs">General Options</TabsTrigger>
                        <TabsTrigger value="receipt" className="text-xs font-semibold rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-xs">Receipt Designer</TabsTrigger>
                        <TabsTrigger value="payment" className="text-xs font-semibold rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-xs">Payment Methods</TabsTrigger>
                    </TabsList>

                    {/* General Settings */}
                    <TabsContent value="general">
                        <Card className="border border-border/60 shadow-xs">
                            <CardHeader>
                                <CardTitle className="text-sm font-bold flex items-center gap-2 text-foreground">
                                    <Keyboard className="w-4 h-4 text-primary" />
                                    <span>General Register Settings</span>
                                </CardTitle>
                                <CardDescription className="text-xs">
                                    Configure core POS rules, constraints, display messages, and localization.
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-5">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-1.5">
                                        <label className="text-xs font-bold text-muted-foreground flex items-center gap-1">
                                            Currency Localization
                                        </label>
                                        <Input
                                            disabled
                                            value={`${settings.currency_symbol} (${settings.currency_code})`}
                                            className="h-10 text-xs bg-muted text-muted-foreground font-semibold input-premium"
                                        />
                                        <p className="text-[10px] text-muted-foreground">
                                            Synchronized from WooCommerce settings.
                                        </p>
                                    </div>

                                    <div className="space-y-1.5">
                                        <label className="text-xs font-bold text-foreground flex items-center gap-1">
                                            <Percent className="w-3.5 h-3.5 text-primary" />
                                            <span>Maximum Cashier Discount (%)</span>
                                        </label>
                                        <Input
                                            type="number"
                                            min="0"
                                            max="100"
                                            placeholder="100"
                                            value={settings.max_discount_limit}
                                            onChange={(e) =>
                                                setSettings((prev) => ({
                                                    ...prev,
                                                    max_discount_limit: Math.min(100, Math.max(0, parseInt(e.target.value) || 0)),
                                                }))
                                            }
                                            className="h-10 text-xs"
                                        />
                                        <p className="text-[10px] text-muted-foreground">
                                            Enforce discount percentage limits on the POS terminal to prevent unauthorized price cuts.
                                        </p>
                                    </div>

                                    <div className="space-y-1.5">
                                        <label className="text-xs font-bold text-foreground flex items-center gap-1">
                                            <Tags className="w-3.5 h-3.5 text-primary" />
                                            <span>POS Invoice Prefix</span>
                                        </label>
                                        <Input
                                            placeholder="RP"
                                            value={settings.pos_order_prefix}
                                            onChange={(e) =>
                                                setSettings((prev) => ({
                                                    ...prev,
                                                    pos_order_prefix: e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, ""),
                                                }))
                                            }
                                            className="h-10 text-xs font-mono uppercase"
                                        />
                                        <p className="text-[10px] text-muted-foreground">
                                            Appended prefix for POS order identifiers (e.g. RP-1002).
                                        </p>
                                    </div>

                                    <div className="space-y-1.5">
                                        <label className="text-xs font-bold text-foreground flex items-center gap-1">
                                            <Tv className="w-3.5 h-3.5 text-primary" />
                                            <span>Customer Display Message</span>
                                        </label>
                                        <Input
                                            placeholder="Welcome to our store!"
                                            value={settings.customer_display_message}
                                            onChange={(e) =>
                                                setSettings((prev) => ({
                                                    ...prev,
                                                    customer_display_message: e.target.value,
                                                }))
                                            }
                                            className="h-10 text-xs"
                                        />
                                        <p className="text-[10px] text-muted-foreground">
                                            Default greeting showing on terminal secondary display screens.
                                        </p>
                                    </div>
                                </div>

                                <Separator className="my-4 opacity-50" />

                                <div className="flex items-center justify-between border p-4 rounded-xl bg-muted/10">
                                    <div className="space-y-0.5">
                                        <label className="text-xs font-bold text-foreground">Global Barcode Listener</label>
                                        <p className="text-[10px] text-muted-foreground max-w-[400px]">
                                            Automatically focus and process barcode scans at any time inside the POS terminal.
                                        </p>
                                    </div>
                                    <Switch
                                        checked={settings.keyboard_status === "yes"}
                                        onCheckedChange={(checked) =>
                                            setSettings((prev) => ({
                                                ...prev,
                                                keyboard_status: checked ? "yes" : "no",
                                            }))
                                        }
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Receipt Designer (Split Layout on Desktop) */}
                    <TabsContent value="receipt">
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                            {/* Layout Editor Controls */}
                            <div className="lg:col-span-7 space-y-4">
                                <Card className="border border-border/60 shadow-xs">
                                    <CardHeader>
                                        <CardTitle className="text-sm font-bold flex items-center gap-2">
                                            <Printer className="w-4 h-4 text-primary" />
                                            <span>Receipt Layout & Print Rule Settings</span>
                                        </CardTitle>
                                        <CardDescription className="text-xs">
                                            Customize your print size, custom headers, custom footers, and logo.
                                        </CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-5">
                                        {/* Paper Width Toggle Buttons */}
                                        <div className="space-y-1.5">
                                            <label className="text-xs font-bold text-foreground">Thermal Paper Print Width</label>
                                            <div className="grid grid-cols-2 gap-3 max-w-xs mt-1">
                                                <Button
                                                    type="button"
                                                    variant={settings.receipt_paper_width === "80mm" ? "default" : "outline"}
                                                    className="h-10 text-xs font-bold transition-all"
                                                    onClick={() =>
                                                        setSettings((prev) => ({
                                                            ...prev,
                                                            receipt_paper_width: "80mm",
                                                        }))
                                                    }
                                                >
                                                    Standard 80mm
                                                </Button>
                                                <Button
                                                    type="button"
                                                    variant={settings.receipt_paper_width === "58mm" ? "default" : "outline"}
                                                    className="h-10 text-xs font-bold transition-all"
                                                    onClick={() =>
                                                        setSettings((prev) => ({
                                                            ...prev,
                                                            receipt_paper_width: "58mm",
                                                        }))
                                                    }
                                                >
                                                    Compact 58mm
                                                </Button>
                                            </div>
                                            <p className="text-[10px] text-muted-foreground mt-1">
                                                Select paper profile configured in your thermal receipt printer.
                                            </p>
                                        </div>

                                        <div className="space-y-1.5">
                                            <label className="text-xs font-bold text-foreground">Receipt Logo URL</label>
                                            <Input
                                                placeholder="https://example.com/logo.png"
                                                value={settings.receipt_logo}
                                                onChange={(e) =>
                                                    setSettings((prev) => ({
                                                        ...prev,
                                                        receipt_logo: e.target.value,
                                                    }))
                                                }
                                                className="h-10 text-xs"
                                            />
                                            <p className="text-[10px] text-muted-foreground">
                                                Image URL of your logo. High contrast black & white images print best on thermal heads.
                                            </p>
                                        </div>

                                        <div className="space-y-1.5">
                                            <label className="text-xs font-bold text-foreground">Header Text / Location Details</label>
                                            <Textarea
                                                placeholder={"READY POS OUTLET HQ\n123 Retail Road, City Plaza\nPhone: (555) 019-2831"}
                                                value={settings.receipt_header}
                                                onChange={(e) =>
                                                    setSettings((prev) => ({
                                                        ...prev,
                                                        receipt_header: e.target.value,
                                                    }))
                                                }
                                                className="text-xs min-h-24 font-mono leading-relaxed"
                                            />
                                            <p className="text-[10px] text-muted-foreground">
                                                Appears at the very top of each printed copy.
                                            </p>
                                        </div>

                                        <div className="space-y-1.5">
                                            <label className="text-xs font-bold text-foreground">Footer / Return Policies</label>
                                            <Textarea
                                                placeholder={"Thank you for shopping with us!\nReturns allowed within 14 days\nwith original receipt invoice."}
                                                value={settings.receipt_footer}
                                                onChange={(e) =>
                                                    setSettings((prev) => ({
                                                        ...prev,
                                                        receipt_footer: e.target.value,
                                                    }))
                                                }
                                                className="text-xs min-h-24 font-mono leading-relaxed"
                                            />
                                            <p className="text-[10px] text-muted-foreground">
                                                Appears below transaction details.
                                            </p>
                                        </div>

                                        <Separator className="my-4 opacity-50" />

                                        <div className="flex items-center justify-between border p-4 rounded-xl bg-muted/10">
                                            <div className="space-y-0.5">
                                                <label className="text-xs font-bold text-foreground">Print Transaction Barcode</label>
                                                <p className="text-[10px] text-muted-foreground">
                                                    Render and print scannable 1D barcode of the order ID for faster returns or audits.
                                                </p>
                                            </div>
                                            <Switch
                                                checked={settings.print_barcode === "yes"}
                                                onCheckedChange={(checked) =>
                                                    setSettings((prev) => ({
                                                        ...prev,
                                                        print_barcode: checked ? "yes" : "no",
                                                    }))
                                                }
                                            />
                                        </div>

                                        <div className="space-y-1.5 border p-4 rounded-xl bg-muted/10 flex flex-col justify-start">
                                            <label className="text-xs font-bold text-foreground">Cash Drawer Pulse Kick Trigger</label>
                                            <p className="text-[10px] text-muted-foreground mb-2">
                                                Select ESC/POS pulse sequence sent to your receipt printer's DK port on cash order settlement.
                                            </p>
                                            <select
                                                value={settings.cash_drawer_pulse || "none"}
                                                onChange={(e) =>
                                                    setSettings((prev) => ({
                                                        ...prev,
                                                        cash_drawer_pulse: e.target.value,
                                                    }))
                                                }
                                                className="w-full max-w-xs h-10 text-xs border rounded-lg bg-background px-3 font-semibold text-foreground focus:ring-2 focus:ring-primary"
                                            >
                                                <option value="none">None (Disabled)</option>
                                                <option value="epson">Epson/Star Standard (ESC p 0 25 250)</option>
                                                <option value="star">Star Line Mode (ESC CD)</option>
                                                <option value="generic">Generic Kick 1 (0x07)</option>
                                            </select>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Beautiful Live Visual 3D Thermal Receipt Preview */}
                            <div className="lg:col-span-5 sticky top-6">
                                <ReceiptPreview settings={settings} />
                            </div>
                        </div>
                    </TabsContent>

                    {/* Payment Settings */}
                    <TabsContent value="payment">
                        <Card className="border border-border/60 shadow-xs">
                            <CardHeader>
                                <CardTitle className="text-sm font-bold flex items-center gap-2">
                                    <CreditCard className="w-4 h-4 text-primary" />
                                    <span>POS Payment Integrations</span>
                                </CardTitle>
                                <CardDescription className="text-xs">
                                    Define payment methods cashier terminal operators can select during guest checkout.
                                </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex items-center justify-between border p-4 rounded-xl bg-muted/10">
                                    <div className="space-y-0.5">
                                        <label className="text-xs font-bold text-foreground">Accept Cash Drawer Payments</label>
                                        <p className="text-[10px] text-muted-foreground max-w-[420px]">
                                            Allow payment via bills and coins. Triggers float logs, change calculation inputs, and cash drawer kickers.
                                        </p>
                                    </div>
                                    <Switch
                                        checked={settings.payment_cash === "yes"}
                                        onCheckedChange={(checked) =>
                                            setSettings((prev) => ({
                                                ...prev,
                                                payment_cash: checked ? "yes" : "no",
                                            }))
                                        }
                                    />
                                </div>

                                <div className="flex items-center justify-between border p-4 rounded-xl bg-muted/10">
                                    <div className="space-y-0.5">
                                        <label className="text-xs font-bold text-foreground">Accept Credit & Debit Cards</label>
                                        <p className="text-[10px] text-muted-foreground max-w-[420px]">
                                            Logs external card machine references (Visa, Mastercard, AMEX) or prompts client card readers.
                                        </p>
                                    </div>
                                    <Switch
                                        checked={settings.payment_card === "yes"}
                                        onCheckedChange={(checked) =>
                                            setSettings((prev) => ({
                                                ...prev,
                                                payment_card: checked ? "yes" : "no",
                                            }))
                                        }
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>

                <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button
                        type="submit"
                        disabled={saving}
                        className="h-10 font-bold px-6 bg-primary text-primary-foreground hover:bg-primary/90 flex items-center gap-1.5 transition-all shadow-md active:scale-98"
                    >
                        {saving ? (
                            <>
                                <span className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin"></span>
                                <span>Saving Settings...</span>
                            </>
                        ) : (
                            <span>Save Settings</span>
                        )}
                    </Button>
                </div>
            </form>
        </div>
    );
}

// Receipt Preview Sub-Component
function ReceiptPreview({ settings }) {
    const is80mm = settings.receipt_paper_width === "80mm";
    const sampleItems = [
        { name: "Organic Espresso Beans (1kg)", qty: 1, price: 24.99 },
        { name: "Double Espresso Shot", qty: 2, price: 7.00 },
        { name: "Gluten-Free Butter Croissant", qty: 3, price: 13.50 },
    ];
    const subtotal = 45.49;
    const tax = 3.64;
    const total = 49.13;

    return (
        <div className="flex flex-col items-center justify-center p-6 bg-zinc-950/95 border border-zinc-800 rounded-2xl shadow-inner min-h-[500px]">
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                Interactive 3D Thermal Print Preview ({settings.receipt_paper_width})
            </span>

            {/* Thermal Ticket Scroll Container */}
            <div 
                className="relative bg-white text-zinc-850 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] border border-zinc-200 transition-all duration-300 rounded-xs select-none"
                style={{ 
                    width: is80mm ? "310px" : "240px",
                    fontFamily: "'Courier New', Courier, monospace",
                    padding: is80mm ? "24px 20px" : "20px 14px",
                }}
            >
                {/* Paper Tear Jagged Top */}
                <div className="absolute top-0 left-0 right-0 h-1.5 bg-repeat-x" 
                    style={{
                        backgroundImage: "radial-gradient(circle, #09090b 1px, transparent 1.5px)",
                        backgroundSize: "5px 6px"
                    }}
                />

                {/* Receipt Content */}
                <div className="flex flex-col items-center text-center space-y-3">
                    {settings.receipt_logo ? (
                        <img 
                            src={settings.receipt_logo} 
                            alt="Receipt Logo" 
                            className="w-14 h-14 object-contain filter grayscale contrast-200 rounded-md"
                            onError={(e) => {
                                e.target.style.display = "none";
                            }}
                        />
                    ) : (
                        <div className="w-12 h-12 rounded-full border-2 border-dashed border-zinc-400 flex items-center justify-center text-zinc-400 text-[10px] font-bold">
                            Logo
                        </div>
                    )}

                    <div className="space-y-1">
                        <h4 className="font-bold text-xs uppercase tracking-wide whitespace-pre-line leading-tight text-zinc-900">
                            {settings.receipt_header || "READY POS STORE"}
                        </h4>
                        <p className="text-[9px] text-zinc-500 leading-tight">
                            Date: {new Date().toLocaleDateString()} &nbsp; Time: {new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </p>
                    </div>
                </div>

                {/* Divider */}
                <div className="border-t border-dashed border-zinc-300 my-3" />

                {/* Transaction Metadata */}
                <div className="text-[9px] space-y-0.5 text-zinc-600">
                    <div className="flex justify-between">
                        <span>Register ID: #RG-001</span>
                        <span>Outlet: Main HQ</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Cashier: Jane Doe</span>
                        <span>Session: #14</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Receipt ID: {settings.pos_order_prefix ? settings.pos_order_prefix + "-90812" : "RP-90812"}</span>
                        <span>Mode: Walk-In</span>
                    </div>
                </div>

                {/* Divider */}
                <div className="border-t border-dashed border-zinc-300 my-3" />

                {/* Line Items */}
                <div className="space-y-2 text-[10px]">
                    <div className="grid grid-cols-12 font-bold border-b border-dashed border-zinc-200 pb-1 text-zinc-500 text-[9px] uppercase">
                        <span className="col-span-6 text-left">Item</span>
                        <span className="col-span-2 text-center">Qty</span>
                        <span className="col-span-4 text-right">Price</span>
                    </div>
                    {sampleItems.map((item, idx) => (
                        <div key={idx} className="grid grid-cols-12 leading-tight gap-y-0.5 text-zinc-800">
                            <span className="col-span-6 truncate font-medium text-left">{item.name}</span>
                            <span className="col-span-2 text-center text-zinc-500">x{item.qty}</span>
                            <span className="col-span-4 text-right">${(item.qty * item.price).toFixed(2)}</span>
                        </div>
                    ))}
                </div>

                {/* Divider */}
                <div className="border-t border-dashed border-zinc-300 my-3" />

                {/* Totals */}
                <div className="space-y-1 text-[10px] font-semibold text-zinc-700">
                    <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Sales Tax (8%):</span>
                        <span>${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-zinc-950 border-t border-dashed border-zinc-200 pt-1.5 mt-1">
                        <span>TOTAL AMOUNT:</span>
                        <span>${total.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-[9px] text-zinc-500 pt-1">
                        <span>Cash Paid:</span>
                        <span>$50.00</span>
                    </div>
                    <div className="flex justify-between text-[9px] text-zinc-500">
                        <span>Change Returned:</span>
                        <span>$0.87</span>
                    </div>
                </div>

                {/* Divider */}
                <div className="border-t border-dashed border-zinc-300 my-3.5" />

                {/* Footer Message */}
                <div className="text-center space-y-3">
                    <p className="text-[9px] font-medium leading-relaxed whitespace-pre-line text-zinc-650">
                        {settings.receipt_footer || "Thank you for shopping with us!"}
                    </p>

                    {/* Live Dynamic Barcode */}
                    {settings.print_barcode === "yes" && (
                        <div className="flex flex-col items-center pt-2">
                            <svg className="w-36 h-10 object-contain text-zinc-950" viewBox="0 0 100 30" xmlns="http://www.w3.org/2000/svg">
                                <rect x="5" y="2" width="2" height="20" fill="currentColor"/>
                                <rect x="9" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="12" y="2" width="3" height="20" fill="currentColor"/>
                                <rect x="17" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="19" y="2" width="2" height="20" fill="currentColor"/>
                                <rect x="23" y="2" width="4" height="20" fill="currentColor"/>
                                <rect x="28" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="31" y="2" width="2" height="20" fill="currentColor"/>
                                <rect x="34" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="37" y="2" width="3" height="20" fill="currentColor"/>
                                <rect x="42" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="44" y="2" width="2" height="20" fill="currentColor"/>
                                <rect x="48" y="2" width="4" height="20" fill="currentColor"/>
                                <rect x="53" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="56" y="2" width="2" height="20" fill="currentColor"/>
                                <rect x="59" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="62" y="2" width="3" height="20" fill="currentColor"/>
                                <rect x="67" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="69" y="2" width="2" height="20" fill="currentColor"/>
                                <rect x="73" y="2" width="4" height="20" fill="currentColor"/>
                                <rect x="78" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="81" y="2" width="2" height="20" fill="currentColor"/>
                                <rect x="84" y="2" width="1" height="20" fill="currentColor"/>
                                <rect x="87" y="2" width="3" height="20" fill="currentColor"/>
                                <rect x="92" y="2" width="2" height="20" fill="currentColor"/>
                                <text x="50" y="28" textAnchor="middle" fontSize="6" fontFamily="monospace" className="fill-zinc-650 font-bold uppercase tracking-wider">
                                    {(settings.pos_order_prefix ? settings.pos_order_prefix + "-90812" : "RP-90812")}
                                </text>
                            </svg>
                        </div>
                    )}
                </div>

                {/* Paper Tear Zigged Bottom */}
                <div className="absolute bottom-0 left-0 right-0 h-2 bg-repeat-x"
                    style={{
                        backgroundImage: "linear-gradient(45deg, transparent 33.333%, #09090b 33.333%, #09090b 66.667%, transparent 66.667%), linear-gradient(-45deg, transparent 33.333%, #09090b 33.333%, #09090b 66.667%, transparent 66.667%)",
                        backgroundSize: "8px 16px",
                        transform: "translateY(2px)"
                    }}
                />
            </div>
        </div>
    );
}