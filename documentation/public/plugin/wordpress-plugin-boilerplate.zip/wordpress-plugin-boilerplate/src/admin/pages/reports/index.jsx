import React, { useState, useEffect } from "react";
import { api } from "@/lib/api";
import { formatPrice } from "@/lib/currency";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { 
    ResponsiveContainer, LineChart, Line, BarChart, Bar, 
    XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell 
} from "recharts";
import { BarChart3, TrendingUp, Users, CreditCard, ShoppingBag, Calendar, RefreshCw } from "lucide-react";

const COLORS = ["#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"];

export default function Reports() {
    const [days, setDays] = useState("30");
    const [loading, setLoading] = useState(false);

    // Data states
    const [salesSummary, setSalesSummary] = useState(null);
    const [salesChart, setSalesChart] = useState([]);
    const [products, setProducts] = useState([]);
    const [cashiers, setCashiers] = useState([]);
    const [payments, setPayments] = useState([]);

    const fetchReportData = async () => {
        setLoading(true);
        try {
            // Fetch all reports in parallel
            const [salesData, productsData, cashiersData, paymentsData] = await Promise.all([
                api.get(`/reports/sales-summary?days=${days}`),
                api.get(`/reports/product-performance?days=${days}`),
                api.get(`/reports/cashier-performance?days=${days}`),
                api.get(`/reports/payment-methods?days=${days}`)
            ]);

            setSalesSummary(salesData?.summary || null);
            setSalesChart(salesData?.chart || []);
            setProducts(productsData || []);
            setCashiers(cashiersData || []);
            setPayments(paymentsData || []);
        } catch (err) {
            toast.error("Failed to load report analytics");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchReportData();
    }, [days]);

    const stats = [
        {
            title: "Gross Sales",
            value: formatPrice(salesSummary?.gross_sales || 0),
            desc: "Total revenue including taxes",
            icon: TrendingUp,
            color: "text-emerald-500 bg-emerald-500/10"
        },
        {
            title: "Net Sales",
            value: formatPrice(salesSummary?.net_sales || 0),
            desc: "Total revenue excluding taxes",
            icon: BarChart3,
            color: "text-sky-500 bg-sky-500/10"
        },
        {
            title: "Orders Placed",
            value: salesSummary?.total_orders || 0,
            desc: "Total transactions checked out",
            icon: ShoppingBag,
            color: "text-amber-500 bg-amber-500/10"
        },
        {
            title: "Total Discounts",
            value: formatPrice(salesSummary?.total_disc || 0),
            desc: "Discounts applied on cart totals",
            icon: CreditCard,
            color: "text-rose-500 bg-rose-500/10"
        }
    ];

    if (loading && !salesSummary) {
        return (
            <div className="h-96 flex flex-col items-center justify-center gap-2">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs text-muted-foreground">Generating business reports...</p>
            </div>
        );
    }

    return (
        <div className="page-container bg-muted/20">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="space-y-1">
                    <h2 className="page-title">
                        <BarChart3 className="w-6 h-6 text-primary" />
                        <span>POS Reports & Analytics</span>
                    </h2>
                    <p className="page-subtitle">
                        Analyze sales summaries, cashier audits, and product performance.
                    </p>
                </div>

                <div className="flex items-center gap-2">
                    <Select value={days} onValueChange={setDays}>
                        <SelectTrigger className="w-40 h-9 text-xs input-premium">
                            <Calendar className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
                            <SelectValue placeholder="Select Range" />
                        </SelectTrigger>
                        <SelectContent className="z-[100000]">
                            <SelectItem value="7" className="text-xs">Last 7 Days</SelectItem>
                            <SelectItem value="30" className="text-xs">Last 30 Days</SelectItem>
                            <SelectItem value="90" className="text-xs">Last 90 Days</SelectItem>
                        </SelectContent>
                    </Select>

                    <Button 
                        variant="outline" 
                        size="icon" 
                        onClick={fetchReportData}
                        disabled={loading}
                        className="h-9 w-9 btn-premium"
                    >
                        <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                    </Button>
                </div>
            </div>

            <Separator className="opacity-40" />

            {/* Stat widgets */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                {stats.map((stat, idx) => {
                    const Icon = stat.icon;
                    return (
                        <div key={idx} className="stat-card p-6 bg-card">
                            <div className="flex items-center justify-between space-y-0 pb-3">
                                <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">{stat.title}</p>
                                <div className={`p-2 rounded-lg ${stat.color}`}>
                                    <Icon className="h-4 w-4" />
                                </div>
                            </div>
                            <div className="space-y-1">
                                <div className="text-2xl font-extrabold text-foreground tracking-tight">{stat.value}</div>
                                <p className="text-[10px] text-muted-foreground mt-0.5">{stat.desc}</p>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Chart Sections */}
            <Tabs defaultValue="sales" className="space-y-4">
                <TabsList className="grid grid-cols-4 max-w-lg bg-muted/10 border p-1 rounded-xl">
                    <TabsTrigger value="sales" className="text-xs font-semibold rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-xs">Sales Trend</TabsTrigger>
                    <TabsTrigger value="products" className="text-xs font-semibold rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-xs">Products Sold</TabsTrigger>
                    <TabsTrigger value="cashiers" className="text-xs font-semibold rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-xs">Cashiers</TabsTrigger>
                    <TabsTrigger value="payments" className="text-xs font-semibold rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-xs">Payments</TabsTrigger>
                </TabsList>

                {/* Sales Trend Tab */}
                <TabsContent value="sales">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-sm font-bold">Revenue Timeline</CardTitle>
                            <CardDescription className="text-xs">Gross sales generated daily.</CardDescription>
                        </CardHeader>
                        <CardContent className="h-[400px] pt-4">
                            {salesChart.length === 0 ? (
                                <div className="h-full flex items-center justify-center text-xs text-muted-foreground">No data available</div>
                            ) : (
                                <ResponsiveContainer width="100%" height="100%">
                                    <LineChart data={salesChart} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                                        <XAxis dataKey="date" tickLine={false} axisLine={false} style={{ fontSize: 10 }} />
                                        <YAxis tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} style={{ fontSize: 10 }} />
                                        <Tooltip 
                                            formatter={(value) => [formatPrice(value), "Sales"]} 
                                            contentStyle={{ fontSize: 11, borderRadius: 8 }}
                                        />
                                        <Line type="monotone" dataKey="sales" stroke="#0ea5e9" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                                    </LineChart>
                                </ResponsiveContainer>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Products Performance Tab */}
                <TabsContent value="products">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-sm font-bold">Top Selling Products</CardTitle>
                            <CardDescription className="text-xs">Highest performing items ranked by units sold.</CardDescription>
                        </CardHeader>
                        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                            {products.length === 0 ? (
                                <div className="col-span-2 h-64 flex items-center justify-center text-xs text-muted-foreground">No products data</div>
                            ) : (
                                <>
                                    <div className="h-[300px]">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={products} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                                                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                                                <XAxis dataKey="name" tickLine={false} axisLine={false} tick={false} />
                                                <YAxis tickLine={false} axisLine={false} style={{ fontSize: 10 }} />
                                                <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                                                <Bar dataKey="quantity" fill="#10b981" radius={[4, 4, 0, 0]} />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                    <div className="border rounded-lg overflow-hidden">
                                        <Table>
                                            <TableHeader className="bg-muted/30">
                                                <TableRow>
                                                    <TableHead className="font-bold text-[10px] uppercase py-2">Product Name</TableHead>
                                                    <TableHead className="font-bold text-[10px] uppercase py-2 text-center">Qty Sold</TableHead>
                                                    <TableHead className="font-bold text-[10px] uppercase py-2 text-right">Revenue</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {products.map((item, idx) => (
                                                    <TableRow key={idx} className="hover:bg-muted/10">
                                                        <TableCell className="text-xs font-semibold py-2 text-foreground truncate max-w-[180px]">{item.name}</TableCell>
                                                        <TableCell className="text-xs text-center py-2 font-bold text-foreground">{item.quantity}</TableCell>
                                                        <TableCell className="text-xs font-black py-2 text-right text-primary">{formatPrice(item.total)}</TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </div>
                                </>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Cashier Performance Tab */}
                <TabsContent value="cashiers">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-sm font-bold">Sales by Cashier</CardTitle>
                            <CardDescription className="text-xs">Transactions logs divided per cashier staff.</CardDescription>
                        </CardHeader>
                        <CardContent className="h-[300px] pt-4">
                            {cashiers.length === 0 ? (
                                <div className="h-full flex items-center justify-center text-xs text-muted-foreground">No cashiers data</div>
                            ) : (
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={cashiers} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                                        <XAxis dataKey="name" tickLine={false} axisLine={false} style={{ fontSize: 10 }} />
                                        <YAxis tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} style={{ fontSize: 10 }} />
                                        <Tooltip 
                                            formatter={(value, name) => [name === "sales" ? formatPrice(value) : value, name === "sales" ? "Total Revenue" : "Orders count"]}
                                            contentStyle={{ fontSize: 11, borderRadius: 8 }}
                                        />
                                        <Legend wrapperStyle={{ fontSize: 10 }} />
                                        <Bar dataKey="sales" name="Total Revenue" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                                    </BarChart>
                                </ResponsiveContainer>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Payment Methods Tab */}
                <TabsContent value="payments">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-sm font-bold">Payment Methods Breakdown</CardTitle>
                            <CardDescription className="text-xs">Comparing cash vs card payment collection volume.</CardDescription>
                        </CardHeader>
                        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                            {payments.length === 0 ? (
                                <div className="col-span-2 h-64 flex items-center justify-center text-xs text-muted-foreground">No payment statistics</div>
                            ) : (
                                <>
                                    <div className="h-[250px] flex items-center justify-center">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Pie
                                                    data={payments}
                                                    cx="50%"
                                                    cy="50%"
                                                    innerRadius={60}
                                                    outerRadius={80}
                                                    paddingAngle={5}
                                                    dataKey="sales"
                                                    nameKey="method"
                                                >
                                                    {payments.map((entry, index) => (
                                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                                    ))}
                                                </Pie>
                                                <Tooltip formatter={(val) => formatPrice(val)} contentStyle={{ fontSize: 11, borderRadius: 8 }} />
                                                <Legend wrapperStyle={{ fontSize: 10 }} />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </div>
                                    <div className="border rounded-lg overflow-hidden h-fit">
                                        <Table>
                                            <TableHeader className="bg-muted/30">
                                                <TableRow>
                                                    <TableHead className="font-bold text-[10px] uppercase py-2">Method</TableHead>
                                                    <TableHead className="font-bold text-[10px] uppercase py-2 text-center">Transactions</TableHead>
                                                    <TableHead className="font-bold text-[10px] uppercase py-2 text-right">Revenue</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {payments.map((item, idx) => (
                                                    <TableRow key={idx} className="hover:bg-muted/10">
                                                        <TableCell className="text-xs font-semibold py-2.5 text-foreground flex items-center gap-1.5">
                                                            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                                                            {item.method}
                                                        </TableCell>
                                                        <TableCell className="text-xs text-center py-2.5 font-bold text-foreground">{item.count}</TableCell>
                                                        <TableCell className="text-xs font-black py-2.5 text-right text-foreground">{formatPrice(item.sales)}</TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </div>
                                </>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
