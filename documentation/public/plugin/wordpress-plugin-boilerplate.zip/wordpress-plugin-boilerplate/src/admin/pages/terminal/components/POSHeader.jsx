import React, { useState, useEffect } from "react";
import { useAtom } from "jotai";
import { sessionAtom, settingsAtom } from "@/admin/stores/posStore";
import { LayoutDashboard, LogOut, Clock, Layers, Moon, Sun, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import { api } from "@/lib/api";
import { toast } from "sonner";
import { formatPrice } from "@/lib/currency";
import CashAdjustModal from "./CashAdjustModal";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";

import { useOfflineSync } from "@/admin/hooks/useOfflineSync";
import { useHardware } from "@/admin/hooks/useHardware";
import { Wifi, WifiOff, AlertTriangle, RefreshCw, Trash2, Printer, ScanBarcode } from "lucide-react";

export default function POSHeader({ 
    onOpenCloseSession, 
    onOpenHeldCarts, 
    onOpenCameraScanner,
    onOpenShiftTracker,
    activeShift
}) {
    const [session, setSession] = useAtom(sessionAtom);
    const [settings] = useAtom(settingsAtom);
    const { theme, setTheme } = useTheme();
    const [time, setTime] = useState(new Date());
    const { isOnline, pendingCount, failedCount, syncOfflineOrders, getFailedOrders, retryFailedOrder, discardFailedOrder } = useOfflineSync();
    const hw = useHardware();
    const [cashAdjustOpen, setCashAdjustOpen] = useState(false);
    const [failedOrdersOpen, setFailedOrdersOpen] = useState(false);
    const [failedOrders, setFailedOrders] = useState([]);

    const handleOpenFailedOrders = async () => {
        const orders = await getFailedOrders();
        setFailedOrders(orders);
        setFailedOrdersOpen(true);
    };

    const refreshFailedList = async () => {
        const orders = await getFailedOrders();
        setFailedOrders(orders);
    };

    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    const handleCloseRegister = async () => {
        if (!session.has_active) return;
        onOpenCloseSession();
    };

    return (
        <header className="h-16 border-b bg-card text-card-foreground flex items-center justify-between px-6 shadow-sm select-none">
            {/* Left: Branding and Dashboard escape */}
            <div className="flex items-center gap-4">
                <a href="#/dashboard" className="flex items-center gap-2 font-bold text-lg text-primary">
                    <span className="bg-primary text-primary-foreground p-1 px-2 rounded-md">R</span>
                    <span>Ready POS</span>
                </a>
                <span className="h-5 w-px bg-border"></span>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">
                        {session.has_active ? `Register 1` : "Register Closed"}
                    </span>
                    {session.has_active && (
                        <span className="bg-emerald-500/10 text-emerald-500 text-xs px-2 py-0.5 rounded-full font-bold">
                            Open
                        </span>
                    )}
                </div>
            </div>

            {/* Middle: Live Clock */}
            <div className="hidden md:flex items-center gap-2 text-sm font-medium text-muted-foreground bg-muted/50 p-2 px-3 rounded-lg">
                <Clock className="w-4 h-4 text-primary" />
                <span>{time.toLocaleDateString()}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-border"></span>
                <span>{time.toLocaleTimeString()}</span>
            </div>

            {/* Right: Actions and User */}
            <div className="flex items-center gap-3">
                {/* Connection Status Badge */}
                {isOnline ? (
                    <div className="flex items-center gap-1.5 bg-emerald-500/10 text-emerald-500 text-xs font-semibold px-2.5 py-1 rounded-full">
                        <Wifi className="w-3.5 h-3.5" />
                        <span>Online</span>
                    </div>
                ) : (
                    <button 
                        onClick={syncOfflineOrders}
                        title="Click to sync offline orders manually"
                        className="flex items-center gap-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 text-xs font-semibold px-2.5 py-1 rounded-full animate-pulse transition-all"
                    >
                        <WifiOff className="w-3.5 h-3.5" />
                        <span>Offline {pendingCount > 0 && `(${pendingCount})`}</span>
                    </button>
                )}

                {/* Failed offline orders alert */}
                {failedCount > 0 && (
                    <button
                        onClick={handleOpenFailedOrders}
                        title="Click to review failed offline orders"
                        className="flex items-center gap-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 text-xs font-bold px-2.5 py-1 rounded-full animate-pulse transition-all"
                    >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{failedCount} Failed</span>
                    </button>
                )}

                {/* Hardware status pills */}
                {hw.printerConnected && (
                    <div
                        title="Thermal printer connected"
                        className="flex items-center gap-1 bg-blue-500/10 text-blue-600 text-[10px] font-bold px-2 py-1 rounded-full"
                    >
                        <Printer className="w-3 h-3" />
                    </div>
                )}
                {hw.scannerConnected && (
                    <div
                        title={`Scanner connected (${hw.scannerMode} mode)`}
                        className="flex items-center gap-1 bg-purple-500/10 text-purple-600 text-[10px] font-bold px-2 py-1 rounded-full"
                    >
                        <ScanBarcode className="w-3 h-3" />
                    </div>
                )}

                {/* Petty Cash Drawer Ledger */}
                {session.has_active && (
                    <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setCashAdjustOpen(true)}
                        className="flex items-center gap-1.5 border-emerald-500/25 bg-emerald-500/5 hover:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:text-emerald-750 font-bold shadow-xs transition-all active:scale-98"
                        title="Manage petty cash drawer adjustments"
                    >
                        <Wallet className="w-4.5 h-4.5 text-emerald-500" />
                        <span>Drawer: {formatPrice((parseFloat(session.session?.opening_cash) || 0) + (parseFloat(session.session?.cash_total) || 0))}</span>
                    </Button>
                )}

                {/* Manual cash drawer kick (when printer/drawer hardware is paired) */}
                {hw.printerConnected && session.has_active && (
                    <Button
                        variant="outline"
                        size="icon"
                        onClick={async () => {
                            try {
                                await hw.openDrawer();
                                toast.success("Drawer opened");
                            } catch (err) {
                                toast.error(err.message || "Failed to open drawer");
                            }
                        }}
                        className="h-9 w-9"
                        title="Open cash drawer"
                    >
                        <Wallet className="w-4 h-4 text-emerald-500" />
                    </Button>
                )}

                {/* Camera Scanner Trigger */}
                <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={onOpenCameraScanner}
                    className="flex items-center gap-1.5"
                    title="Scan item barcode with device camera"
                >
                    <span className="w-2 h-2 rounded-full bg-primary animate-ping" />
                    <span>Camera Scan</span>
                </Button>

                <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={onOpenHeldCarts}
                    className="flex items-center gap-1.5"
                >

                    <Layers className="w-4 h-4" />
                    <span>Held Carts</span>
                </Button>

                <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={onOpenShiftTracker}
                    className="flex items-center gap-1.5"
                    title={activeShift ? "View Shift Tracker / Clock Out" : "Clock In Shift"}
                >
                    <Clock className={`w-4 h-4 ${activeShift ? "text-amber-500 animate-pulse" : "text-muted-foreground"}`} />
                    <span>{activeShift ? "Shift Active" : "Shift Inactive"}</span>
                </Button>

                <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                    className="rounded-full"
                >
                    {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                </Button>

                <span className="h-5 w-px bg-border"></span>

                <div className="flex items-center gap-3">
                    <div className="text-right">
                        <div className="text-xs font-semibold text-foreground">
                            {typeof readyPosAdmin !== "undefined" ? readyPosAdmin.userInfo.username : "Cashier"}
                        </div>
                        <div className="text-[10px] text-muted-foreground capitalize">
                            {typeof readyPosAdmin !== "undefined" ? readyPosAdmin.userInfo.roles.join(", ") : "Staff"}
                        </div>
                    </div>
                </div>

                <span className="h-5 w-px bg-border"></span>

                {session.has_active ? (
                    <Button 
                        variant="destructive" 
                        size="sm" 
                        onClick={handleCloseRegister}
                        className="flex items-center gap-1.5"
                    >
                        <LogOut className="w-4 h-4" />
                        <span>Close Register</span>
                    </Button>
                ) : (
                    <Button 
                        variant="default" 
                        size="sm" 
                        onClick={onOpenCloseSession}
                        className="flex items-center gap-1.5"
                    >
                        <span>Open Register</span>
                    </Button>
                )}

                <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => window.location.href = "#/dashboard"}
                    title="Exit to Dashboard"
                >
                    <LayoutDashboard className="w-5 h-5 text-muted-foreground hover:text-foreground" />
                </Button>
            </div>

            <CashAdjustModal open={cashAdjustOpen} onOpenChange={setCashAdjustOpen} />

            {/* Failed Offline Orders Modal */}
            <Dialog open={failedOrdersOpen} onOpenChange={setFailedOrdersOpen}>
                <DialogContent className="max-w-2xl rounded-xl select-none max-h-[85vh] flex flex-col">
                    <DialogHeader>
                        <DialogTitle className="text-base font-bold flex items-center gap-2 text-rose-600">
                            <AlertTriangle className="w-5 h-5" />
                            <span>Failed Offline Orders ({failedOrders.length})</span>
                        </DialogTitle>
                        <DialogDescription className="text-xs">
                            These orders couldn't be synced to the server after multiple attempts. Review the error, retry manually, or discard.
                        </DialogDescription>
                    </DialogHeader>

                    <div className="flex-1 overflow-y-auto space-y-2 py-2">
                        {failedOrders.length === 0 ? (
                            <div className="h-32 flex flex-col items-center justify-center text-muted-foreground gap-2">
                                <span className="text-xs font-semibold">No failed orders</span>
                            </div>
                        ) : (
                            failedOrders.map((order) => (
                                <div key={order.localId} className="border border-rose-500/20 bg-rose-500/5 rounded-lg p-3 space-y-2">
                                    <div className="flex items-start justify-between gap-3">
                                        <div className="space-y-0.5 flex-1 min-w-0">
                                            <div className="text-xs font-bold text-foreground">
                                                Order {order.localId.replace(/^pos_/, "")}
                                            </div>
                                            <div className="text-[10px] text-muted-foreground">
                                                {new Date(order._createdAt).toLocaleString()} · {order.items?.length || 0} items · Tries: {order._retryCount}
                                            </div>
                                            {order._lastError && (
                                                <div className="text-[10px] text-rose-600 font-mono bg-rose-500/10 rounded px-2 py-1 mt-1 break-words">
                                                    {order._lastError}
                                                </div>
                                            )}
                                        </div>
                                        <div className="flex gap-1 shrink-0">
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={async () => {
                                                    await retryFailedOrder(order.localId);
                                                    refreshFailedList();
                                                }}
                                                className="h-7 text-[10px] font-bold gap-1"
                                            >
                                                <RefreshCw className="w-3 h-3" />
                                                Retry
                                            </Button>
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={async () => {
                                                    if (confirm("Discard this order? This cannot be undone.")) {
                                                        await discardFailedOrder(order.localId);
                                                        refreshFailedList();
                                                    }
                                                }}
                                                className="h-7 text-[10px] font-bold gap-1 text-rose-500 hover:bg-rose-500/10"
                                            >
                                                <Trash2 className="w-3 h-3" />
                                                Discard
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>

                    <DialogFooter className="border-t pt-3">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setFailedOrdersOpen(false)}
                        >
                            Close
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </header>
    );
}
