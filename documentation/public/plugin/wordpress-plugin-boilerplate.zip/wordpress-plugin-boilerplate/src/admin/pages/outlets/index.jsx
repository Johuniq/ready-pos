import React, { useState, useEffect } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Store, Plus, Edit2, Phone, Mail, MapPin, RefreshCw } from "lucide-react";
import InventoryTakeModal from "./components/InventoryTakeModal";

export default function Outlets() {
    const [outlets, setOutlets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [modalMode, setModalMode] = useState("create"); // "create" or "edit"
    
    // Inventory take state
    const [showInventoryModal, setShowInventoryModal] = useState(false);
    const [selectedOutletForInventory, setSelectedOutletForInventory] = useState(null);
    
    // Form fields
    const [currentId, setCurrentId] = useState(null);
    const [name, setName] = useState("");
    const [address, setAddress] = useState("");
    const [phone, setPhone] = useState("");
    const [email, setEmail] = useState("");
    const [receiptHeader, setReceiptHeader] = useState("");
    const [receiptFooter, setReceiptFooter] = useState("");
    const [saving, setSaving] = useState(false);

    const fetchOutlets = async () => {
        setLoading(true);
        try {
            const data = await api.get("/settings/outlets");
            setOutlets(data || []);
        } catch (err) {
            toast.error("Failed to load outlets");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchOutlets();
    }, []);

    const handleOpenCreate = () => {
        setModalMode("create");
        setCurrentId(null);
        setName("");
        setAddress("");
        setPhone("");
        setEmail("");
        setReceiptHeader("");
        setReceiptFooter("");
        setShowModal(true);
    };

    const handleOpenEdit = (outlet) => {
        setModalMode("edit");
        setCurrentId(outlet.id);
        setName(outlet.name || "");
        setAddress(outlet.address || "");
        setPhone(outlet.phone || "");
        setEmail(outlet.email || "");
        setReceiptHeader(outlet.receipt_header || "");
        setReceiptFooter(outlet.receipt_footer || "");
        setShowModal(true);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            if (modalMode === "create") {
                await api.post("/settings/outlets/create", {
                    name, address, phone, email,
                    receipt_header: receiptHeader,
                    receipt_footer: receiptFooter
                });
                toast.success("Outlet created successfully");
            } else {
                await api.post("/settings/outlets/update", {
                    id: currentId,
                    name, address, phone, email,
                    receipt_header: receiptHeader,
                    receipt_footer: receiptFooter
                });
                toast.success("Outlet updated successfully");
            }
            setShowModal(false);
            fetchOutlets();
        } catch (err) {
            toast.error(err.message || "Failed to save outlet");
        } finally {
            setSaving(false);
        }
    };

    if (loading && outlets.length === 0) {
        return (
            <div className="h-96 flex flex-col items-center justify-center gap-2 font-sans select-none">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs text-muted-foreground">Loading outlets...</p>
            </div>
        );
    }

    return (
        <div className="page-container bg-muted/20">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="space-y-1">
                    <h2 className="page-title">
                        <Store className="w-6 h-6 text-primary" />
                        <span>Store Outlets</span>
                    </h2>
                    <p className="page-subtitle">
                        Manage physical store outlets and check status of linked cash registers.
                    </p>
                </div>
                <Button onClick={handleOpenCreate} size="sm" className="font-bold flex items-center gap-1.5 bg-primary text-primary-foreground hover:bg-primary/95 btn-premium">
                    <Plus className="w-4 h-4" /> Add Outlet
                </Button>
            </div>

            <Separator className="opacity-40" />

            {outlets.length === 0 ? (
                <div className="h-48 border-2 border-dashed rounded-xl flex flex-col items-center justify-center text-muted-foreground gap-2">
                    <Store className="w-10 h-10 opacity-30" />
                    <p className="font-semibold text-sm">No outlets configured</p>
                    <p className="text-xs">Click "Add Outlet" to configure your first retail branch.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {outlets.map((outlet) => (
                        <Card key={outlet.id} className="card-elevated overflow-hidden flex flex-col justify-between">
                            <CardHeader className="bg-muted/10 pb-4">
                                <div className="flex justify-between items-start">
                                    <div className="space-y-1">
                                        <CardTitle className="text-sm font-bold flex items-center gap-2 text-foreground">
                                            <Store className="w-4 h-4 text-primary" />
                                            {outlet.name}
                                        </CardTitle>
                                        <div className="flex items-center gap-1.5 mt-1">
                                            <Badge variant="outline" className="text-[9px] font-bold uppercase tracking-wider py-0 px-2">
                                                ID: {outlet.id}
                                            </Badge>
                                            <Badge 
                                                className={`badge-status ${
                                                    outlet.status === "active" 
                                                        ? "badge-success" 
                                                        : "badge-warning"
                                                }`}
                                            >
                                                {outlet.status}
                                            </Badge>
                                        </div>
                                    </div>
                                    <Button 
                                        variant="ghost" 
                                        size="icon" 
                                        onClick={() => handleOpenEdit(outlet)}
                                        className="h-8 w-8 rounded-full btn-premium"
                                        title="Edit Outlet"
                                    >
                                        <Edit2 className="w-3.5 h-3.5" />
                                    </Button>
                                </div>
                            </CardHeader>
                            <CardContent className="pt-4 space-y-4 flex-1">
                                {/* Details list */}
                                <div className="space-y-2 text-xs">
                                    {outlet.address && (
                                        <div className="flex items-start gap-2 text-muted-foreground">
                                            <MapPin className="w-4 h-4 shrink-0 mt-0.5" />
                                            <span>{outlet.address}</span>
                                        </div>
                                    )}
                                    {outlet.phone && (
                                        <div className="flex items-center gap-2 text-muted-foreground">
                                            <Phone className="w-4 h-4" />
                                            <span>{outlet.phone}</span>
                                        </div>
                                    )}
                                    {outlet.email && (
                                        <div className="flex items-center gap-2 text-muted-foreground">
                                            <Mail className="w-4 h-4" />
                                            <span>{outlet.email}</span>
                                        </div>
                                    )}
                                </div>

                                <Separator />

                                {/* Registers */}
                                <div className="space-y-2">
                                    <h4 className="text-xs font-bold text-foreground flex items-center gap-1.5">
                                        Registers ({outlet.registers?.length || 0})
                                    </h4>
                                    <div className="space-y-1.5">
                                        {outlet.registers && outlet.registers.length > 0 ? (
                                            outlet.registers.map((reg) => (
                                                <div key={reg.id} className="flex justify-between items-center bg-muted/30 p-2 rounded-lg text-xs border border-border/40">
                                                    <span className="font-semibold text-foreground flex items-center gap-1.5">
                                                        <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                                                        {reg.name}
                                                    </span>
                                                    <Badge 
                                                        variant={reg.status === "open" ? "default" : "secondary"}
                                                        className={`text-[9px] font-extrabold uppercase px-2 ${
                                                            reg.status === "open" 
                                                                ? "bg-emerald-500 hover:bg-emerald-600 text-white" 
                                                                : ""
                                                        }`}
                                                    >
                                                        {reg.status}
                                                    </Badge>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="text-[10px] text-muted-foreground italic p-2 bg-muted/20 rounded-lg">
                                                No registers linked to this outlet.
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </CardContent>
                            <CardFooter className="bg-muted/5 border-t px-6 py-3 flex justify-end gap-2 shrink-0">
                                <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-[10px] h-8 font-bold flex items-center gap-1.5 hover:bg-primary/5 hover:text-primary transition-all duration-150"
                                    onClick={() => {
                                        setSelectedOutletForInventory(outlet);
                                        setShowInventoryModal(true);
                                    }}
                                >
                                    <RefreshCw className="w-3.5 h-3.5 text-primary" />
                                    <span>Inventory Audit Take</span>
                                </Button>
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            )}

            {/* Create / Edit Dialog */}
            <Dialog open={showModal} onOpenChange={setShowModal}>
                <DialogContent className="max-w-md rounded-xl select-none overflow-hidden max-h-[90vh]">
                    <DialogHeader className="pb-4 border-b">
                        <DialogTitle className="text-base font-bold flex items-center gap-1.5">
                            <Store className="w-5 h-5 text-primary" />
                            <span>{modalMode === "create" ? "Add New Outlet" : "Edit Outlet Details"}</span>
                        </DialogTitle>
                    </DialogHeader>

                    <form onSubmit={handleSubmit} className="space-y-4 pt-4 overflow-y-auto max-h-[60vh] pr-2">
                        {/* Name */}
                        <div className="space-y-1">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase">Outlet Name</label>
                            <Input
                                required
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="e.g. Downtown Branch"
                                className="h-10 text-xs font-semibold"
                            />
                        </div>

                        {/* Phone & Email */}
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                                <label className="text-[10px] font-bold text-muted-foreground uppercase">Phone</label>
                                <Input
                                    value={phone}
                                    onChange={(e) => setPhone(e.target.value)}
                                    placeholder="+1 555-0199"
                                    className="h-10 text-xs"
                                />
                            </div>
                            <div className="space-y-1">
                                <label className="text-[10px] font-bold text-muted-foreground uppercase">Email</label>
                                <Input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder="outlet@store.com"
                                    className="h-10 text-xs"
                                />
                            </div>
                        </div>

                        {/* Address */}
                        <div className="space-y-1">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase">Address</label>
                            <Textarea
                                value={address}
                                onChange={(e) => setAddress(e.target.value)}
                                placeholder="Enter street address..."
                                className="text-xs min-h-16 resize-none"
                            />
                        </div>

                        <Separator />

                        <div className="space-y-1">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase">Receipt Custom Header</label>
                            <Textarea
                                value={receiptHeader}
                                onChange={(e) => setReceiptHeader(e.target.value)}
                                placeholder="If empty, default header is used."
                                className="text-xs min-h-16 resize-none"
                            />
                        </div>

                        <div className="space-y-1">
                            <label className="text-[10px] font-bold text-muted-foreground uppercase">Receipt Custom Footer</label>
                            <Textarea
                                value={receiptFooter}
                                onChange={(e) => setReceiptFooter(e.target.value)}
                                placeholder="If empty, default footer is used."
                                className="text-xs min-h-16 resize-none"
                            />
                        </div>

                        <DialogFooter className="pt-4 border-t flex gap-2">
                            <Button 
                                type="button" 
                                variant="outline" 
                                onClick={() => setShowModal(false)}
                                className="flex-1 text-xs h-10 font-semibold"
                            >
                                Cancel
                            </Button>
                            <Button 
                                type="submit" 
                                disabled={saving}
                                className="flex-1 text-xs h-10 font-bold bg-primary text-primary-foreground hover:bg-primary/95"
                            >
                                {saving ? "Saving..." : "Save Outlet"}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>

            {/* Inventory Take Dialog */}
            <InventoryTakeModal
                open={showInventoryModal}
                onOpenChange={setShowInventoryModal}
                outlet={selectedOutletForInventory}
                onComplete={fetchOutlets}
            />
        </div>
    );
}
