import React, { useEffect, useMemo, useRef, useState } from "react";
import { api } from "@/lib/api";
import { formatPrice } from "@/lib/currency";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
    Users,
    Plus,
    Search,
    RefreshCw,
    Pencil,
    Trash2,
    Mail,
    Phone,
    Star,
    AlertTriangle,
    Eye,
} from "lucide-react";
import CustomerFormModal from "./components/CustomerFormModal";
import CustomerDetailModal from "./components/CustomerDetailModal";

const PAGE_LIMIT = 20;

export default function Customers() {
    const [customers, setCustomers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [search, setSearch] = useState("");
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);

    // Form modal state
    const [showForm, setShowForm] = useState(false);
    const [formMode, setFormMode] = useState("create");
    const [editing, setEditing] = useState(null);

    // Delete confirm state
    const [deleteTarget, setDeleteTarget] = useState(null);
    const [deleting, setDeleting] = useState(false);

    // Detail modal state
    const [detailCustomer, setDetailCustomer] = useState(null);

    const searchTimer = useRef(null);

    const fetchCustomers = async (targetPage = page, term = search) => {
        setLoading(true);
        try {
            const data = await api.get("/customers/list", {
                page: targetPage,
                limit: PAGE_LIMIT,
                search: term,
            });
            setCustomers(data?.customers || []);
            setTotalPages(data?.total_pages || 1);
            setTotal(data?.total || 0);
            setPage(data?.page || targetPage);
        } catch (err) {
            toast.error(err.message || "Failed to load customers");
        } finally {
            setLoading(false);
        }
    };

    // Initial load
    useEffect(() => {
        fetchCustomers(1, "");
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Debounced search
    useEffect(() => {
        if (searchTimer.current) clearTimeout(searchTimer.current);
        searchTimer.current = setTimeout(() => {
            fetchCustomers(1, search);
        }, 300);
        return () => clearTimeout(searchTimer.current);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [search]);

    const handleOpenCreate = () => {
        setFormMode("create");
        setEditing(null);
        setShowForm(true);
    };

    const handleOpenEdit = (customer) => {
        setFormMode("edit");
        setEditing(customer);
        setShowForm(true);
    };

    const handleSaved = () => {
        // Reload current page so totals stay accurate
        fetchCustomers(page, search);
    };

    const handleDelete = async () => {
        if (!deleteTarget) return;
        setDeleting(true);
        try {
            await api.post("/customers/delete", { id: deleteTarget.id });
            toast.success(`Deleted ${deleteTarget.first_name || "customer"}`);
            setDeleteTarget(null);
            // If we just removed the last row on the page, step back one page.
            const nextPage = customers.length === 1 && page > 1 ? page - 1 : page;
            fetchCustomers(nextPage, search);
        } catch (err) {
            toast.error(err.message || "Failed to delete customer");
        } finally {
            setDeleting(false);
        }
    };

    const initialOf = (c) => (c.first_name?.[0] || c.username?.[0] || "?").toUpperCase();

    const summary = useMemo(() => {
        if (loading) return "Loading customers…";
        if (total === 0) return "No customers yet";
        const start = (page - 1) * PAGE_LIMIT + 1;
        const end = Math.min(page * PAGE_LIMIT, total);
        return `Showing ${start}-${end} of ${total}`;
    }, [loading, total, page]);

    return (
        <div className="page-container bg-muted/20">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="space-y-1">
                    <h2 className="page-title">
                        <Users className="w-6 h-6 text-primary" />
                        <span>Customers</span>
                    </h2>
                    <p className="page-subtitle">
                        Manage POS customers. Records here are shared with the terminal and WooCommerce.
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fetchCustomers(page, search)}
                        disabled={loading}
                        className="h-9 text-xs font-semibold btn-premium"
                    >
                        <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} />
                        Refresh
                    </Button>
                    <Button
                        onClick={handleOpenCreate}
                        size="sm"
                        className="h-9 font-bold flex items-center gap-1.5 bg-primary text-primary-foreground hover:bg-primary/95 btn-premium"
                    >
                        <Plus className="w-4 h-4" /> Add Customer
                    </Button>
                </div>
            </div>

            <Separator className="opacity-40" />

            {/* Search bar */}
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div className="relative w-full sm:max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Search by name, email, or phone..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="pl-9 h-10 text-xs"
                    />
                </div>
                <span className="text-[11px] text-muted-foreground font-semibold">{summary}</span>
            </div>

            {/* Table */}
            <Card className="border border-border/60 shadow-sm overflow-hidden">
                <CardContent className="p-0">
                    {loading && customers.length === 0 ? (
                        <div className="h-64 flex flex-col items-center justify-center gap-2">
                            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                            <p className="text-xs text-muted-foreground">Loading customers...</p>
                        </div>
                    ) : customers.length === 0 ? (
                        <div className="h-64 flex flex-col items-center justify-center text-muted-foreground gap-2">
                            <Users className="w-10 h-10 opacity-30" />
                            <p className="font-semibold text-sm">No customers found</p>
                            <p className="text-xs">
                                {search
                                    ? "Try a different search term."
                                    : "Add your first customer or create one from the POS terminal."}
                            </p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <Table className="premium-table">
                                <TableHeader>
                                    <TableRow className="hover:bg-transparent">
                                        <TableHead className="pl-6 font-bold uppercase text-[10px] tracking-wider">Customer</TableHead>
                                        <TableHead className="font-bold uppercase text-[10px] tracking-wider">Contact</TableHead>
                                        <TableHead className="font-bold uppercase text-[10px] tracking-wider text-center">Visits</TableHead>
                                        <TableHead className="font-bold uppercase text-[10px] tracking-wider text-right">Total Spent</TableHead>
                                        <TableHead className="font-bold uppercase text-[10px] tracking-wider text-center">Loyalty</TableHead>
                                        <TableHead className="w-28 pr-6 font-bold uppercase text-[10px] tracking-wider text-right">Actions</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {customers.map((c) => (
                                        <TableRow key={c.id} className="hover:bg-muted/10 border-b border-border/50">
                                            <TableCell className="pl-6 py-3">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm">
                                                        {initialOf(c)}
                                                    </div>
                                                    <div className="space-y-0.5">
                                                        <div className="text-xs font-bold text-foreground">
                                                            {c.first_name} {c.last_name}
                                                        </div>
                                                        <div className="text-[10px] text-muted-foreground">
                                                            @{c.username}
                                                        </div>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-xs text-muted-foreground">
                                                <div className="space-y-0.5">
                                                    {c.email && (
                                                        <div className="flex items-center gap-1.5">
                                                            <Mail className="w-3 h-3" />
                                                            <span>{c.email}</span>
                                                        </div>
                                                    )}
                                                    {c.phone && (
                                                        <div className="flex items-center gap-1.5">
                                                            <Phone className="w-3 h-3" />
                                                            <span>{c.phone}</span>
                                                        </div>
                                                    )}
                                                    {!c.email && !c.phone && (
                                                        <span className="italic text-[10px]">No contact info</span>
                                                    )}
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-xs font-semibold text-foreground text-center">
                                                {c.visit_count || 0}
                                            </TableCell>
                                            <TableCell className="text-xs font-bold text-foreground text-right">
                                                {formatPrice(c.total_spent || 0)}
                                            </TableCell>
                                            <TableCell className="text-center">
                                                <Badge
                                                    variant="outline"
                                                    className="text-[10px] font-bold flex items-center gap-1 mx-auto w-fit"
                                                >
                                                    <Star className="w-3 h-3 text-amber-500" />
                                                    {c.loyalty_points || 0}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-right pr-6">
                                                <div className="flex items-center justify-end gap-1">
                                                    <Button
                                                        variant="outline"
                                                        size="icon"
                                                        className="h-8 w-8 rounded-full btn-premium"
                                                        onClick={() => setDetailCustomer(c)}
                                                        title="View Details"
                                                    >
                                                        <Eye className="w-3.5 h-3.5" />
                                                    </Button>
                                                    <Button
                                                        variant="outline"
                                                        size="icon"
                                                        className="h-8 w-8 rounded-full btn-premium"
                                                        onClick={() => handleOpenEdit(c)}
                                                        title="Edit"
                                                    >
                                                        <Pencil className="w-3.5 h-3.5" />
                                                    </Button>
                                                    <Button
                                                        variant="outline"
                                                        size="icon"
                                                        className="h-8 w-8 rounded-full text-rose-500 hover:bg-rose-500/10 hover:text-rose-600"
                                                        onClick={() => setDeleteTarget(c)}
                                                        title="Delete"
                                                    >
                                                        <Trash2 className="w-3.5 h-3.5" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </CardContent>

                {totalPages > 1 && (
                    <div className="flex justify-between items-center p-4 border-t text-xs">
                        <span className="text-muted-foreground">
                            Page <b>{page}</b> of <b>{totalPages}</b>
                        </span>
                        <div className="flex gap-2">
                            <Button
                                variant="outline"
                                size="sm"
                                disabled={page <= 1 || loading}
                                onClick={() => fetchCustomers(page - 1, search)}
                                className="h-8 text-xs font-semibold"
                            >
                                Previous
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                disabled={page >= totalPages || loading}
                                onClick={() => fetchCustomers(page + 1, search)}
                                className="h-8 text-xs font-semibold"
                            >
                                Next
                            </Button>
                        </div>
                    </div>
                )}
            </Card>

            {/* Create / Edit modal (shared with POS terminal) */}
            <CustomerFormModal
                open={showForm}
                onOpenChange={setShowForm}
                mode={formMode}
                customer={editing}
                onSaved={handleSaved}
            />

            {/* Delete confirmation modal */}
            <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
                <DialogContent className="max-w-sm rounded-xl select-none">
                    <DialogHeader>
                        <DialogTitle className="text-base font-bold flex items-center gap-2 text-rose-600">
                            <AlertTriangle className="w-5 h-5" />
                            <span>Delete customer?</span>
                        </DialogTitle>
                        <DialogDescription className="text-xs">
                            This will permanently remove
                            {" "}
                            <b className="text-foreground">
                                {deleteTarget?.first_name} {deleteTarget?.last_name}
                            </b>
                            {" "}
                            from WooCommerce and the POS database. Linked order history is preserved but the user account will be reassigned. This cannot be undone.
                        </DialogDescription>
                    </DialogHeader>

                    <DialogFooter className="pt-2 flex gap-2">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() => setDeleteTarget(null)}
                            disabled={deleting}
                            className="flex-1 text-xs h-10 font-semibold"
                        >
                            Cancel
                        </Button>
                        <Button
                            type="button"
                            onClick={handleDelete}
                            disabled={deleting}
                            className="flex-1 text-xs h-10 font-bold bg-rose-500 hover:bg-rose-600 text-white"
                        >
                            {deleting ? "Deleting..." : "Delete"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Customer detail / purchase history modal */}
            <CustomerDetailModal
                open={!!detailCustomer}
                onOpenChange={(open) => !open && setDetailCustomer(null)}
                customer={detailCustomer}
            />
        </div>
    );
}
