import { useEffect } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { toast } from "sonner";

export default function LayoutOne() {
    // Determine context (admin vs frontend)
    const isAdmin = typeof readyPosAdmin !== "undefined" ? readyPosAdmin.isAdmin : true;
    const showApplicationLayout = !isAdmin;
    const isCashier = typeof readyPosAdmin !== "undefined" && readyPosAdmin.userInfo?.roles?.includes("pos_cashier");
    
    const location = useLocation();
    const navigate = useNavigate();
    const pageTitle = location.pathname.split("/")[1];

    useEffect(() => {
        if (isCashier) {
            // Cashier role lockdown: lock cashiers in the terminal view
            const restrictedPaths = ["", "dashboard", "orders", "reports", "outlets", "settings", "customers", "hardware"];
            if (restrictedPaths.includes(pageTitle || "")) {
                navigate("terminal");
                if (pageTitle && pageTitle !== "terminal" && pageTitle !== "customer-display") {
                    toast.error("Access denied. Standard cashiers are restricted from back-office areas.");
                }
            }
        } else {
            // Check if onboarding is needed
            const onboardingComplete = typeof readyPosAdmin !== "undefined" ? readyPosAdmin.onboardingComplete : true;
            
            if (!onboardingComplete && pageTitle !== "onboarding") {
                navigate("onboarding");
                return;
            }

            // Standard Shop Manager / Admin redirect
            if (!pageTitle || pageTitle === "") {
                navigate("dashboard");
            }
        }
    }, [pageTitle, navigate, isCashier]);

    // Handle full-screen layout styles for WP admin area
    useEffect(() => {
        if (isAdmin) {
            const isTerminal = location.pathname.includes("/terminal");
            const wpWrap = document.getElementById("wpwrap");
            
            if (isTerminal) {
                document.body.classList.add("readypos-terminal-active");
                if (wpWrap) wpWrap.classList.add("readypos-terminal-active-wrap");
                
                // Add absolute style overrides to completely hide WP UI elements
                const styleId = "readypos-fullscreen-style";
                if (!document.getElementById(styleId)) {
                    const style = document.createElement("style");
                    style.id = styleId;
                    style.innerHTML = `
                        .readypos-terminal-active #adminmenuback,
                        .readypos-terminal-active #adminmenuwrap,
                        .readypos-terminal-active #wpadminbar,
                        .readypos-terminal-active #wpfooter {
                            display: none !important;
                        }
                        .readypos-terminal-active #wpcontent {
                            margin-left: 0 !important;
                            padding: 0 !important;
                        }
                        .readypos-terminal-active #wpbody-content {
                            padding-bottom: 0 !important;
                        }
                        .readypos-terminal-active #wpbody {
                            padding-top: 0 !important;
                        }
                        .readypos-terminal-active .readypos-app, 
                        .readypos-terminal-active #myplugin {
                            height: 100vh !important;
                            width: 100vw !important;
                            position: fixed !important;
                            top: 0 !important;
                            left: 0 !important;
                            z-index: 99999 !important;
                            background: white;
                        }
                        /* Dark mode fullscreen override */
                        .dark.readypos-terminal-active .readypos-app {
                            background: rgb(17, 24, 39);
                        }
                        
                        /* Ensure all Radix portals (Modals, Dropdowns, Selects), toasts, and overlays render on top of the fullscreen terminal (z-index 99999) */
                        [data-radix-portal] {
                            z-index: 100000 !important;
                        }
                        [data-sonner-toaster] {
                            z-index: 100001 !important;
                        }
                        .readypos-terminal-active .fixed.z-50 {
                            z-index: 100000 !important;
                        }
                    `;
                    document.head.appendChild(style);
                }
            } else {
                document.body.classList.remove("readypos-terminal-active");
                if (wpWrap) wpWrap.classList.remove("readypos-terminal-active-wrap");
            }
        }
    }, [location.pathname, isAdmin]);

    return (
        <div className="w-full min-h-screen bg-background font-sans antialiased text-foreground">
            <main className="w-full h-full">
                <Outlet />
            </main>
        </div>
    );
}
