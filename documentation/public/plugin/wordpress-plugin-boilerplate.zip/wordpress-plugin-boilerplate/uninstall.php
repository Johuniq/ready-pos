<?php
/**
 * Uninstall the plugin.
 *
 * Cleans up POS tables and custom roles upon plugin uninstallation.
 *
 * @package Readypos
 * @subpackage Database
 */

use Readypos\Database\Migrations\POSOutlets;
use Readypos\Database\Migrations\POSRegisters;
use Readypos\Database\Migrations\POSSessions;
use Readypos\Database\Migrations\POSOrderMeta;
use Readypos\Database\Migrations\POSCustomers;
use Readypos\Core\Roles;

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/vendor/autoload.php';

// Drop POS tables.
POSOutlets::down();
POSRegisters::down();
POSSessions::down();
POSOrderMeta::down();
POSCustomers::down();

// Remove custom roles and capabilities.
Roles::get_instance()->remove_roles();
